module.exports = {
  reactStrictMode: true,
  images: {
    domains: [
      'cdn.jsdelivr.net',
      'cryptologos.cc',
      'flagcdn.com',
      'firebasestorage.googleapis.com'
    ]
  }
}