import React, { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { loginUser, loginSuperAdmin } from '../../firebase/auth';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../../components/common/Icon';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';

const Login = () => {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  
  // Si déjà connecté, rediriger vers dashboard
  if (isAuthenticated) {
    router.push('/dashboard');
    return null;
  }
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const result = await loginUser(formData.email, formData.password);
      
      if (result.success) {
        router.push('/dashboard');
      } else {
        setError(result.error || 'Échec de la connexion');
      }
    } catch (err) {
      setError('Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSuperAdminLogin = async () => {
    setLoading(true);
    setError('');
    
    try {
      const result = await loginSuperAdmin();
      
      if (result.success) {
        router.push('/god/dashboard');
      } else {
        setError(result.error || 'Échec de la connexion Super Admin');
      }
    } catch (err) {
      setError('Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img src="/logo.png" alt="Pay Fusion" className="h-16 w-auto" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Pay Fusion</h1>
          <p className="text-gray-600 mt-2">Connexion à votre compte</p>
        </div>
        
        {/* Carte de connexion */}
        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Email ou téléphone"
              name="email"
              type="text"
              value={formData.email}
              onChange={handleChange}
              placeholder="exemple@email.com"
              icon="email"
              required
            />
            
            <Input
              label="Mot de passe"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              icon="lock"
              required
            />
            
            {/* Lien mot de passe oublié */}
            <div className="text-right">
              <Link href="/auth/forgot-password" className="text-sm text-[#D4AF37] hover:underline">
                Mot de passe oublié ?
              </Link>
            </div>
            
            {/* Bouton de connexion */}
            <Button
              type="submit"
              variant="primary"
              size="large"
              loading={loading}
              className="w-full"
            >
              Se connecter
            </Button>
            
            {/* Super Admin Login (seulement pour démo/test) */}
            {process.env.NODE_ENV === 'development' && (
              <div className="border-t border-gray-200 pt-4">
                <button
                  type="button"
                  onClick={handleSuperAdminLogin}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-white rounded-lg hover:opacity-90 transition-opacity"
                >
                  <Icon name="crown" size="20px" />
                  <span className="font-semibold">Connexion Super Admin</span>
                </button>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Pour l'accès administration complet
                </p>
              </div>
            )}
            
            {/* Message d'erreur */}
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                <Icon name="error" size="18px" color="#DC2626" />
                <span className="text-red-700 text-sm">{error}</span>
              </div>
            )}
          </form>
        </Card>
        
        {/* Lien vers inscription */}
        <div className="mt-6 text-center">
          <p className="text-gray-600">
            Vous n'avez pas de compte ?{' '}
            <Link href="/auth/register" className="text-[#D4AF37] font-semibold hover:underline">
              S'inscrire
            </Link>
          </p>
        </div>
        
        {/* Sécurité */}
        <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center gap-3">
            <Icon name="shield" size="20px" color="#2563EB" />
            <div>
              <h4 className="font-medium text-blue-900">Connexion sécurisée</h4>
              <p className="text-sm text-blue-700">
                Toutes vos données sont chiffrées avec SSL 256-bit
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;