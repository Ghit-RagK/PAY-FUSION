import React, { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { resetPassword } from '../../firebase/auth';
import Icon from '../../components/common/Icon';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';

const ForgotPassword = () => {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [email, setEmail] = useState('');
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);
    
    if (!email) {
      setError('Veuillez entrer votre email');
      setLoading(false);
      return;
    }
    
    try {
      const result = await resetPassword(email);
      
      if (result.success) {
        setSuccess(true);
        // Rediriger après 3 secondes
        setTimeout(() => {
          router.push('/auth/login');
        }, 3000);
      } else {
        setError(result.error || 'Échec de l\'envoi de l\'email');
      }
    } catch (err) {
      setError('Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img src="/logo.png" alt="Pay Fusion" className="h-16 w-auto" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Mot de passe oublié</h1>
          <p className="text-gray-600 mt-2">Réinitialisez votre mot de passe</p>
        </div>
        
        {/* Carte */}
        <Card className="p-8">
          {success ? (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center">
                <Icon name="success" size="32px" color="#10B981" />
              </div>
              
              <h2 className="text-xl font-semibold text-gray-900">
                Email envoyé avec succès !
              </h2>
              
              <p className="text-gray-600">
                Un lien de réinitialisation a été envoyé à <strong>{email}</strong>.
                Vérifiez votre boîte mail et suivez les instructions.
              </p>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-700">
                  Redirection vers la page de connexion dans 3 secondes...
                </p>
              </div>
              
              <Button
                variant="primary"
                onClick={() => router.push('/auth/login')}
                className="w-full"
              >
                Retour à la connexion
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <p className="text-gray-600">
                Entrez l'adresse email associée à votre compte. Nous vous enverrons
                un lien pour réinitialiser votre mot de passe.
              </p>
              
              <Input
                label="Adresse email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="exemple@email.com"
                icon="email"
                required
              />
              
              {/* Message d'erreur */}
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                  <Icon name="error" size="18px" color="#DC2626" />
                  <span className="text-red-700 text-sm">{error}</span>
                </div>
              )}
              
              <Button
                type="submit"
                variant="primary"
                loading={loading}
                className="w-full"
              >
                Envoyer le lien de réinitialisation
              </Button>
            </form>
          )}
        </Card>
        
        {/* Liens */}
        <div className="mt-6 text-center space-y-4">
          <p className="text-gray-600">
            <Link href="/auth/login" className="text-[#D4AF37] font-semibold hover:underline">
              ← Retour à la connexion
            </Link>
          </p>
          
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-3">
              <Icon name="warning" size="20px" color="#D97706" />
              <div>
                <h4 className="font-medium text-yellow-900">Sécurité</h4>
                <p className="text-sm text-yellow-700">
                  Le lien de réinitialisation est valide 1 heure seulement
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;