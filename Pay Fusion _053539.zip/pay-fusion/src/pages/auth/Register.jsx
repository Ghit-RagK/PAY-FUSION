import React, { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { registerUser } from '../../firebase/auth';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../../components/common/Icon';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';

const Register = () => {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState(1); // 1: Infos de base, 2: Téléphone, 3: Mot de passe
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    birthDate: '',
    phone: '',
    country: 'HT',
    email: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false
  });
  
  // Si déjà connecté, rediriger vers dashboard
  if (isAuthenticated) {
    router.push('/dashboard');
    return null;
  }
  
  const countries = [
    { code: 'HT', name: 'Haïti', flag: 'haiti' },
    { code: 'FR', name: 'France', flag: 'france' },
    { code: 'US', name: 'États-Unis', flag: 'usa' },
    { code: 'CA', name: 'Canada', flag: 'canada' },
    { code: 'BE', name: 'Belgique', flag: 'be' },
    { code: 'CH', name: 'Suisse', flag: 'ch' },
    // Ajouter d'autres pays selon besoin
  ];
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    setError('');
  };
  
  const validateStep1 = () => {
    if (!formData.firstName.trim()) {
      setError('Le prénom est requis');
      return false;
    }
    if (!formData.lastName.trim()) {
      setError('Le nom est requis');
      return false;
    }
    if (!formData.birthDate) {
      setError('La date de naissance est requise');
      return false;
    }
    
    // Vérifier l'âge (18 ans minimum)
    const birthDate = new Date(formData.birthDate);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (age < 18 || (age === 18 && monthDiff < 0)) {
      setError('Vous devez avoir au moins 18 ans');
      return false;
    }
    
    return true;
  };
  
  const validateStep2 = () => {
    if (!formData.phone.trim()) {
      setError('Le numéro de téléphone est requis');
      return false;
    }
    if (!formData.email.trim()) {
      setError('L\'email est requis');
      return false;
    }
    
    // Validation email basique
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Email invalide');
      return false;
    }
    
    return true;
  };
  
  const validateStep3 = () => {
    if (!formData.password) {
      setError('Le mot de passe est requis');
      return false;
    }
    if (formData.password.length < 8) {
      setError('Le mot de passe doit faire au moins 8 caractères');
      return false;
    }
    if (!/[A-Z]/.test(formData.password)) {
      setError('Le mot de passe doit contenir une majuscule');
      return false;
    }
    if (!/[0-9]/.test(formData.password)) {
      setError('Le mot de passe doit contenir un chiffre');
      return false;
    }
    if (!/[!@#$%^&*]/.test(formData.password)) {
      setError('Le mot de passe doit contenir un caractère spécial');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return false;
    }
    if (!formData.acceptTerms) {
      setError('Vous devez accepter les conditions d\'utilisation');
      return false;
    }
    
    return true;
  };
  
  const nextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    }
  };
  
  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (step === 3 && !validateStep3()) {
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      // Créer l'utilisateur dans Firebase
      const result = await registerUser(formData.email, formData.password, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        birthDate: formData.birthDate,
        phone: formData.phone,
        country: formData.country,
        email: formData.email,
        createdAt: new Date().toISOString(),
        kycStatus: 'pending'
      });
      
      if (result.success) {
        // Rediriger vers la page KYC
        router.push('/kyc');
      } else {
        setError(result.error || 'Échec de l\'inscription');
      }
    } catch (err) {
      setError('Une erreur est survenue lors de l\'inscription');
    } finally {
      setLoading(false);
    }
  };
  
  const getPasswordStrength = (password) => {
    if (!password) return 0;
    
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[!@#$%^&*]/.test(password)) strength += 25;
    
    return strength;
  };
  
  const passwordStrength = getPasswordStrength(formData.password);
  const strengthColor = 
    passwordStrength >= 75 ? 'bg-green-500' :
    passwordStrength >= 50 ? 'bg-yellow-500' :
    passwordStrength >= 25 ? 'bg-orange-500' : 'bg-red-500';
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Logo et titre */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img src="/logo.png" alt="Pay Fusion" className="h-16 w-auto" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Créer un compte</h1>
          <p className="text-gray-600 mt-2">Rejoignez Pay Fusion en quelques étapes</p>
        </div>
        
        {/* Indicateur d'étape */}
        <div className="flex items-center justify-center mb-8">
          {[1, 2, 3].map((stepNumber) => (
            <React.Fragment key={stepNumber}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold
                ${step === stepNumber 
                  ? 'bg-[#D4AF37] text-white' 
                  : step > stepNumber
                  ? 'bg-green-100 text-green-600'
                  : 'bg-gray-200 text-gray-500'
                }`}
              >
                {step > stepNumber ? '✓' : stepNumber}
              </div>
              
              {stepNumber < 3 && (
                <div className={`w-24 h-1 mx-2 
                  ${step > stepNumber ? 'bg-green-500' : 'bg-gray-300'}`}
                ></div>
              )}
            </React.Fragment>
          ))}
        </div>
        
        {/* Étapes */}
        <Card className="p-8">
          <form onSubmit={handleSubmit}>
            {/* Étape 1: Informations personnelles */}
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Informations personnelles
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Prénom"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="John"
                    required
                  />
                  
                  <Input
                    label="Nom"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    placeholder="Doe"
                    required
                  />
                </div>
                
                <Input
                  label="Date de naissance"
                  name="birthDate"
                  type="date"
                  value={formData.birthDate}
                  onChange={handleChange}
                  required
                />
                
                <div className="flex justify-between">
                  <div></div> {/* Espacement */}
                  <Button
                    type="button"
                    onClick={nextStep}
                    variant="primary"
                  >
                    Continuer
                  </Button>
                </div>
              </div>
            )}
            
            {/* Étape 2: Contact */}
            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Coordonnées
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Pays
                    </label>
                    <div className="relative">
                      <select
                        name="country"
                        value={formData.country}
                        onChange={handleChange}
                        className="w-full px-4 py-2.5 rounded-lg border border-gray-300 bg-white appearance-none"
                      >
                        {countries.map(country => (
                          <option key={country.code} value={country.code}>
                            {country.name}
                          </option>
                        ))}
                      </select>
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                        <Icon name="arrow-down" size="16px" />
                      </div>
                    </div>
                  </div>
                  
                  <Input
                    label="Numéro de téléphone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+509 44 44 4444"
                    icon="phone"
                    required
                  />
                </div>
                
                <Input
                  label="Adresse email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="exemple@email.com"
                  icon="email"
                  required
                />
                
                <div className="flex justify-between">
                  <Button
                    type="button"
                    onClick={prevStep}
                    variant="ghost"
                  >
                    ← Retour
                  </Button>
                  
                  <Button
                    type="button"
                    onClick={nextStep}
                    variant="primary"
                  >
                    Continuer
                  </Button>
                </div>
              </div>
            )}
            
            {/* Étape 3: Sécurité */}
            {step === 3 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Sécurité du compte
                </h2>
                
                <Input
                  label="Mot de passe"
                  name="password"
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                />
                
                {/* Indicateur de force du mot de passe */}
                {formData.password && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Force du mot de passe:</span>
                      <span className="font-medium">{passwordStrength}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${strengthColor} transition-all duration-300`}
                        style={{ width: `${passwordStrength}%` }}
                      ></div>
                    </div>
                  </div>
                )}
                
                <Input
                  label="Confirmer le mot de passe"
                  name="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                />
                
                {/* Conditions d'utilisation */}
                <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="acceptTerms"
                    name="acceptTerms"
                    checked={formData.acceptTerms}
                    onChange={handleChange}
                    className="mt-1 w-5 h-5"
                  />
                  <label htmlFor="acceptTerms" className="text-sm text-gray-700">
                    J'accepte les{' '}
                    <Link href="/terms" className="text-[#D4AF37] hover:underline">
                      Conditions d'utilisation
                    </Link>{' '}
                    et la{' '}
                    <Link href="/privacy" className="text-[#D4AF37] hover:underline">
                      Politique de confidentialité
                    </Link>{' '}
                    de Pay Fusion
                  </label>
                </div>
                
                {/* Message d'erreur */}
                {error && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                    <Icon name="error" size="18px" color="#DC2626" />
                    <span className="text-red-700 text-sm">{error}</span>
                  </div>
                )}
                
                <div className="flex justify-between">
                  <Button
                    type="button"
                    onClick={prevStep}
                    variant="ghost"
                  >
                    ← Retour
                  </Button>
                  
                  <Button
                    type="submit"
                    variant="primary"
                    loading={loading}
                  >
                    Créer mon compte
                  </Button>
                </div>
              </div>
            )}
          </form>
        </Card>
        
        {/* Lien vers connexion */}
        <div className="mt-6 text-center">
          <p className="text-gray-600">
            Vous avez déjà un compte ?{' '}
            <Link href="/auth/login" className="text-[#D4AF37] font-semibold hover:underline">
              Se connecter
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;