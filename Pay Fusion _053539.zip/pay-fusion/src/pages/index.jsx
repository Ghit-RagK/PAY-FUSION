import React, { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/common/Button';
import Icon from '../components/common/Icon';

const HomePage = () => {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  
  useEffect(() => {
    if (isAuthenticated) {
      router.push('/dashboard');
    }
  }, [isAuthenticated, router]);
  
  // Les 8 cryptos supportées
  const cryptos = [
    { id: 'btc', name: 'Bitcoin', symbol: 'BTC' },
    { id: 'eth', name: 'Ethereum', symbol: 'ETH' },
    { id: 'bnb', name: 'Binance Coin', symbol: 'BNB' },
    { id: 'sol', name: 'Solana', symbol: 'SOL' },
    { id: 'trx', name: 'Tron', symbol: 'TRX' },
    { id: 'usdt', name: 'Tether', symbol: 'USDT' },
    { id: 'matic', name: 'Polygon', symbol: 'MATIC' },
    { id: 'usd', name: 'USD Coin', symbol: 'USD' }
  ];
  
  const steps = [
    {
      icon: 'user',
      title: 'Inscription',
      description: 'Créez votre compte en 2 minutes'
    },
    {
      icon: 'verified',
      title: 'Vérification KYC',
      description: 'Validation manuelle par notre équipe'
    },
    {
      icon: 'bank',
      title: 'Dépôt de fonds',
      description: 'Rechargez via Wise ou autres méthodes'
    },
    {
      icon: 'exchange',
      title: 'Trading sécurisé',
      description: 'Achetez, vendez, échangez vos cryptos'
    }
  ];
  
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Pay Fusion" className="h-10 w-auto" />
            <span className="text-2xl font-bold text-[#1A1A1A]">Pay Fusion</span>
          </div>
          
          <div className="flex items-center gap-4">
            <select className="px-3 py-1.5 border border-gray-300 rounded-lg bg-white">
              <option value="fr">🇫🇷 Français</option>
              <option value="ht">🇭🇹 Kreyòl</option>
              <option value="en">🇺🇸 English</option>
            </select>
            
            <Button 
              variant="primary"
              onClick={() => router.push('/login')}
            >
              Se connecter
            </Button>
          </div>
        </div>
      </header>
      
      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-5xl font-bold text-[#1A1A1A] mb-4">
            Pay Fusion
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Fusionnez vos paiements, maîtrisez vos cryptos
          </p>
          
          <Button
            size="large"
            variant="primary"
            onClick={() => router.push('/register')}
            className="text-lg px-8"
          >
            Commencer maintenant
          </Button>
        </div>
      </section>
      
      {/* Cryptos Supportées */}
      <section className="container mx-auto px-6 py-12">
        <h2 className="text-3xl font-bold text-center text-[#1A1A1A] mb-8">
          8 Cryptomonnaies Supportées
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {cryptos.map((crypto) => (
            <div 
              key={crypto.id}
              className="bg-gray-50 rounded-xl p-6 flex flex-col items-center justify-center hover:shadow-lg transition-shadow duration-200"
            >
              <Icon name={crypto.id} size="64px" />
              <h3 className="mt-4 font-semibold text-gray-900">{crypto.name}</h3>
              <span className="text-gray-500">{crypto.symbol}</span>
            </div>
          ))}
        </div>
      </section>
      
      {/* Processus en 4 étapes */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-[#1A1A1A] mb-12">
            Comment ça marche ?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto bg-[#D4AF37] rounded-full flex items-center justify-center text-white mb-4">
                  <Icon name={step.icon} size="24px" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-600">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="border-t border-gray-200 py-8">
        <div className="container mx-auto px-6 text-center text-gray-500">
          <p>© {new Date().getFullYear()} Pay Fusion. Tous droits réservés.</p>
          <p className="mt-2">contact@payfusion.com</p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;