import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Sidebar from '../../components/layout/Sidebar';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';
import Converter from '../../components/crypto/Converter';
import { getAllCryptoPrices } from '../../services/binance';

const Swap = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [loading, setLoading] = useState(true);
  const [cryptoPrices, setCryptoPrices] = useState([]);
  const [fromCrypto, setFromCrypto] = useState('BTC');
  const [toCrypto, setToCrypto] = useState('ETH');
  const [amount, setAmount] = useState('1');
  const [swapQuote, setSwapQuote] = useState(null);
  const [confirming, setConfirming] = useState(false);
  
  const cryptos = [
    { symbol: 'BTC', name: 'Bitcoin' },
    { symbol: 'ETH', name: 'Ethereum' },
    { symbol: 'BNB', name: 'Binance Coin' },
    { symbol: 'SOL', name: 'Solana' },
    { symbol: 'TRX', name: 'Tron' },
    { symbol: 'USDT', name: 'Tether' },
    { symbol: 'MATIC', name: 'Polygon' },
    { symbol: 'USD', name: 'USD Coin' }
  ];
  
  useEffect(() => {
    loadCryptoPrices();
    
    // Refresh prices every 30 seconds
    const interval = setInterval(loadCryptoPrices, 30000);
    
    return () => clearInterval(interval);
  }, []);
  
  useEffect(() => {
    calculateSwapQuote();
  }, [fromCrypto, toCrypto, amount, cryptoPrices]);
  
  const loadCryptoPrices = async () => {
    try {
      const prices = await getAllCryptoPrices();
      setCryptoPrices(prices);
      setLoading(false);
    } catch (error) {
      console.error('Error loading crypto prices:', error);
    }
  };
  
  const calculateSwapQuote = () => {
    if (!amount || isNaN(amount) || cryptoPrices.length === 0) {
      setSwapQuote(null);
      return;
    }
    
    const fromPrice = cryptoPrices.find(c => c?.symbol === fromCrypto)?.price;
    const toPrice = cryptoPrices.find(c => c?.symbol === toCrypto)?.price;
    
    if (!fromPrice || !toPrice) {
      setSwapQuote(null);
      return;
    }
    
    const exchangeRate = toPrice / fromPrice;
    const receiveAmount = parseFloat(amount) * exchangeRate;
    
    // Calcul des frais (0.1% + frais réseau estimés)
    const feePercentage = 0.1; // 0.1%
    const networkFees = {
      BTC: 0.0005,
      ETH: 0.005,
      BNB: 0.001,
      SOL: 0.01,
      TRX: 1,
      USDT: 10,
      MATIC: 2,
      USD: 0
    };
    
    const swapFee = receiveAmount * (feePercentage / 100);
    const estimatedNetworkFee = networkFees[toCrypto] || 0;
    const totalFees = swapFee + estimatedNetworkFee;
    const finalAmount = receiveAmount - totalFees;
    
    setSwapQuote({
      exchangeRate,
      receiveAmount,
      swapFee,
      networkFee: estimatedNetworkFee,
      totalFees,
      finalAmount,
      estimatedTime: '2-5 minutes'
    });
  };
  
  if (!user) {
    router.push('/auth/login');
    return null;
  }
  
  const handleSwap = () => {
    setConfirming(true);
    
    // Simulation d'échange
    setTimeout(() => {
      alert(`Échange réussi !\n${amount} ${fromCrypto} → ${swapQuote?.finalAmount.toFixed(6)} ${toCrypto}`);
      setConfirming(false);
      
      // Reset form
      setAmount('1');
      setFromCrypto('BTC');
      setToCrypto('ETH');
    }, 2000);
  };
  
  const swapCurrencies = () => {
    const temp = fromCrypto;
    setFromCrypto(toCrypto);
    setToCrypto(temp);
  };
  
  const quickAmounts = [0.1, 0.5, 1, 5, 10];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />
        
        <div className="flex-1">
          <Header />
          
          <main className="p-6">
            <div className="max-w-4xl mx-auto">
              {/* Titre */}
              <div className="mb-8 text-center">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Échanger des cryptos</h1>
                <p className="text-gray-600">
                  Échangez instantanément entre 8 cryptomonnaies supportées
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Formulaire d'échange */}
                <div className="lg:col-span-2">
                  <Card className="p-6">
                    <div className="space-y-6">
                      {/* Section "De" */}
                      <div className="bg-gray-50 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-4">
                          <label className="text-sm font-medium text-gray-700">De</label>
                          <div className="text-xs text-gray-500">
                            Solde disponible: <span className="font-medium">1.5 {fromCrypto}</span>
                          </div>
                        </div>
                        
                        <div className="flex gap-4">
                          <div className="flex-1">
                            <input
                              type="number"
                              value={amount}
                              onChange={(e) => setAmount(e.target.value)}
                              placeholder="0.00"
                              className="w-full text-3xl font-bold bg-transparent border-none outline-none"
                            />
                            <div className="text-sm text-gray-500 mt-1">
                              ≈ ${(parseFloat(amount || 0) * (cryptoPrices.find(c => c?.symbol === fromCrypto)?.price || 0)).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                              })}
                            </div>
                          </div>
                          
                          <div className="relative w-40">
                            <select
                              value={fromCrypto}
                              onChange={(e) => setFromCrypto(e.target.value)}
                              className="w-full h-full px-4 py-3 rounded-lg border border-gray-300 bg-white appearance-none font-medium"
                            >
                              {cryptos.map(crypto => (
                                <option key={crypto.symbol} value={crypto.symbol}>
                                  {crypto.symbol}
                                </option>
                              ))}
                            </select>
                            
                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                              <Icon name="arrow-down" size="16px" />
                            </div>
                            
                            <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                              <Icon name={fromCrypto.toLowerCase()} size="24px" />
                            </div>
                          </div>
                        </div>
                        
                        {/* Quick amounts */}
                        <div className="flex gap-2 mt-4">
                          {quickAmounts.map(quickAmount => (
                            <button
                              key={quickAmount}
                              onClick={() => setAmount(quickAmount.toString())}
                              className="px-3 py-1.5 text-sm bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
                            >
                              {quickAmount} {fromCrypto}
                            </button>
                          ))}
                          <button
                            onClick={() => setAmount('1.5')}
                            className="px-3 py-1.5 text-sm bg-[#D4AF37] text-white hover:bg-[#B8941F] rounded-lg transition-colors"
                          >
                            MAX
                          </button>
                        </div>
                      </div>
                      
                      {/* Swap button */}
                      <div className="flex justify-center">
                        <button
                          onClick={swapCurrencies}
                          className="p-3 bg-[#D4AF37] text-white rounded-full hover:bg-[#B8941F] transition-colors transform hover:rotate-180 duration-300"
                        >
                          <Icon name="exchange" size="24px" />
                        </button>
                      </div>
                      
                      {/* Section "Vers" */}
                      <div className="bg-gray-50 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-4">
                          <label className="text-sm font-medium text-gray-700">Vers</label>
                          <div className="text-xs text-gray-500">
                            Solde disponible: <span className="font-medium">25 {toCrypto}</span>
                          </div>
                        </div>
                        
                        <div className="flex gap-4">
                          <div className="flex-1">
                            <input
                              type="text"
                              value={swapQuote ? swapQuote.finalAmount.toFixed(6) : '0.000000'}
                              readOnly
                              className="w-full text-3xl font-bold bg-transparent border-none outline-none"
                            />
                            <div className="text-sm text-gray-500 mt-1">
                              ≈ ${swapQuote ? (swapQuote.finalAmount * (cryptoPrices.find(c => c?.symbol === toCrypto)?.price || 0)).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                              }) : '0.00'}
                            </div>
                          </div>
                          
                          <div className="relative w-40">
                            <select
                              value={toCrypto}
                              onChange={(e) => setToCrypto(e.target.value)}
                              className="w-full h-full px-4 py-3 rounded-lg border border-gray-300 bg-white appearance-none font-medium"
                            >
                              {cryptos.map(crypto => (
                                <option key={crypto.symbol} value={crypto.symbol}>
                                  {crypto.symbol}
                                </option>
                              ))}
                            </select>
                            
                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                              <Icon name="arrow-down" size="16px" />
                            </div>
                            
                            <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                              <Icon name={toCrypto.toLowerCase()} size="24px" />
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Détails de l'échange */}
                      {swapQuote && (
                        <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                          <h4 className="font-medium text-blue-900 mb-3">Détails de l'échange</h4>
                          
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Taux de change</span>
                              <span className="font-medium">
                                1 {fromCrypto} = {swapQuote.exchangeRate.toFixed(6)} {toCrypto}
                              </span>
                            </div>
                            
                            <div className="flex justify-between">
                              <span className="text-gray-600">Montant à recevoir</span>
                              <span className="font-medium">
                                {swapQuote.receiveAmount.toFixed(6)} {toCrypto}
                              </span>
                            </div>
                            
                            <div className="flex justify-between">
                              <span className="text-gray-600">Frais d'échange (0.1%)</span>
                              <span className="text-red-600 font-medium">
                                -{swapQuote.swapFee.toFixed(6)} {toCrypto}
                              </span>
                            </div>
                            
                            <div className="flex justify-between">
                              <span className="text-gray-600">Frais réseau estimés</span>
                              <span className="text-red-600 font-medium">
                                -{swapQuote.networkFee} {toCrypto}
                              </span>
                            </div>
                            
                            <div className="border-t border-blue-200 pt-2">
                              <div className="flex justify-between font-semibold">
                                <span>Montant final</span>
                                <span className="text-green-600">
                                  {swapQuote.finalAmount.toFixed(6)} {toCrypto}
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex justify-between text-xs text-blue-700">
                              <span>Temps estimé</span>
                              <span>{swapQuote.estimatedTime}</span>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Bouton d'échange */}
                      <Button
                        variant="primary"
                        size="large"
                        icon="exchange"
                        loading={confirming}
                        onClick={handleSwap}
                        disabled={!amount || parseFloat(amount) <= 0 || !swapQuote}
                        className="w-full"
                      >
                        {confirming ? 'Traitement en cours...' : 'Échanger maintenant'}
                      </Button>
                      
                      {/* Avertissement */}
                      <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                        <div className="flex items-start gap-3">
                          <Icon name="warning" size="20px" color="#D97706" />
                          <div className="text-sm text-yellow-700">
                            <p className="font-medium mb-1">Important</p>
                            <p>
                              • Les taux sont actualisés en temps réel<br />
                              • Les frais réseau varient selon la congestion<br />
                              • Les échanges sont irréversibles
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
                
                {/* Convertisseur et info */}
                <div className="space-y-6">
                  <Converter />
                  
                  <Card title="Informations importantes" icon="info">
                    <div className="space-y-3 text-sm">
                      <div className="flex items-start gap-2">
                        <Icon name="verified" size="16px" className="text-green-600 mt-0.5" />
                        <span>Échanges sécurisés avec chiffrement SSL</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Icon name="clock" size="16px" className="text-blue-600 mt-0.5" />
                        <span>Exécution rapide en 2-5 minutes</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Icon name="shield" size="16px" className="text-purple-600 mt-0.5" />
                        <span>Pas de limites d'échange</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Icon name="dollar" size="16px" className="text-[#D4AF37] mt-0.5" />
                        <span>Support 8 cryptomonnaies principales</span>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
              
              {/* Historique des échanges (optionnel) */}
              <div className="mt-8">
                <Card title="Derniers échanges" icon="history">
                  <div className="space-y-3">
                    {[
                      { from: 'BTC', to: 'ETH', amount: '0.1 → 3.2', status: 'Terminé', time: '2 min' },
                      { from: 'USDT', to: 'SOL', amount: '1000 → 8.5', status: 'Terminé', time: '3 min' },
                      { from: 'ETH', to: 'BTC', amount: '2 → 0.065', status: 'Terminé', time: '4 min' }
                    ].map((swap, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center">
                            <Icon name={swap.from.toLowerCase()} size="20px" />
                            <Icon name="arrow-right" size="16px" className="mx-2" />
                            <Icon name={swap.to.toLowerCase()} size="20px" />
                          </div>
                          <div>
                            <div className="font-medium">{swap.from} → {swap.to}</div>
                            <div className="text-sm text-gray-500">{swap.amount}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-xs font-medium px-2 py-1 rounded-full ${
                            swap.status === 'Terminé' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {swap.status}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">{swap.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          </main>
          
          <Footer />
        </div>
      </div>
      
      {/* Tools Super Admin */}
      {isGod && <GodTools />}
    </div>
  );
};

export default Swap;