import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Sidebar from '../../components/layout/Sidebar';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';
import Modal from '../../components/common/Modal';
import { formatCurrency } from '../../utils/currencies';

const Wallet = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  
  // Données de démo
  const [walletData] = useState({
    totalBalance: 12500.75,
    currencies: {
      USD: { balance: 5000, available: 5000 },
      EUR: { balance: 3200, available: 3200 },
      HTG: { balance: 150000, available: 150000 }
    },
    cryptos: [
      { symbol: 'BTC', name: 'Bitcoin', balance: 0.5, value: 35000, change24h: 2.5 },
      { symbol: 'ETH', name: 'Ethereum', balance: 3.2, value: 9600, change24h: 1.8 },
      { symbol: 'BNB', name: 'Binance Coin', balance: 5, value: 1500, change24h: -0.5 },
      { symbol: 'SOL', name: 'Solana', balance: 25, value: 3750, change24h: 5.2 },
      { symbol: 'USDT', name: 'Tether', balance: 5000, value: 5000, change24h: 0.1 },
      { symbol: 'TRX', name: 'Tron', balance: 1000, value: 120, change24h: 1.2 },
      { symbol: 'MATIC', name: 'Polygon', balance: 200, value: 160, change24h: 3.4 }
    ],
    transactions: [
      { id: 1, type: 'deposit', asset: 'USD', amount: 10000, date: '2024-01-15', status: 'completed' },
      { id: 2, type: 'buy', asset: 'BTC', amount: 0.5, date: '2024-01-14', status: 'completed' },
      { id: 3, type: 'sell', asset: 'ETH', amount: 1, date: '2024-01-13', status: 'completed' },
      { id: 4, type: 'withdraw', asset: 'USD', amount: 500, date: '2024-01-12', status: 'pending' },
      { id: 5, type: 'swap', asset: 'BTC→ETH', amount: 0.2, date: '2024-01-11', status: 'completed' }
    ]
  });
  
  if (!user) {
    router.push('/auth/login');
    return null;
  }
  
  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble' },
    { id: 'deposit', label: 'Dépôt' },
    { id: 'withdraw', label: 'Retrait' },
    { id: 'transactions', label: 'Transactions' }
  ];
  
  const getTransactionIcon = (type) => {
    switch(type) {
      case 'deposit': return { icon: 'download', color: 'text-green-600', bg: 'bg-green-100' };
      case 'withdraw': return { icon: 'upload', color: 'text-red-600', bg: 'bg-red-100' };
      case 'buy': return { icon: 'buy', color: 'text-blue-600', bg: 'bg-blue-100' };
      case 'sell': return { icon: 'sell', color: 'text-orange-600', bg: 'bg-orange-100' };
      case 'swap': return { icon: 'exchange', color: 'text-purple-600', bg: 'bg-purple-100' };
      default: return { icon: 'transaction', color: 'text-gray-600', bg: 'bg-gray-100' };
    }
  };
  
  const renderOverview = () => (
    <div className="space-y-6">
      {/* Solde total */}
      <Card variant="primary" icon="wallet" title="Solde total">
        <div className="text-center py-6">
          <div className="text-5xl font-bold mb-2">
            {formatCurrency(walletData.totalBalance, 'USD')}
          </div>
          <p className="text-gray-600">Disponible pour le trading</p>
        </div>
      </Card>
      
      {/* Devises Fiat */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Devises Fiat</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(walletData.currencies).map(([currency, data]) => (
            <Card key={currency} className="text-center">
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {formatCurrency(data.balance, currency)}
              </div>
              <div className="text-sm text-gray-600 mb-4">{currency}</div>
              <div className="flex gap-2">
                <Button
                  variant="primary"
                  size="small"
                  className="flex-1"
                  onClick={() => {
                    setActiveTab('deposit');
                    setShowDepositModal(true);
                  }}
                >
                  Dépôt
                </Button>
                <Button
                  variant="secondary"
                  size="small"
                  className="flex-1"
                  onClick={() => {
                    setActiveTab('withdraw');
                    setShowWithdrawModal(true);
                  }}
                >
                  Retrait
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
      
      {/* Cryptos */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Cryptomonnaies</h3>
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Crypto</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Solde</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Valeur</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Variation 24h</th>
                  <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {walletData.cryptos.map((crypto, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <Icon name={crypto.symbol.toLowerCase()} size="32px" />
                        <div>
                          <div className="font-medium text-gray-900">{crypto.name}</div>
                          <div className="text-sm text-gray-500">{crypto.symbol}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">{crypto.balance}</div>
                      <div className="text-sm text-gray-500">{crypto.symbol}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-gray-900">
                        {formatCurrency(crypto.value, 'USD')}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className={`flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        <Icon name={crypto.change24h >= 0 ? 'arrow-up' : 'arrow-down'} size="16px" />
                        <span className="font-medium">
                          {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button
                          variant="primary"
                          size="small"
                          onClick={() => router.push(`/buy?crypto=${crypto.symbol}`)}
                        >
                          Acheter
                        </Button>
                        <Button
                          variant="secondary"
                          size="small"
                          onClick={() => router.push(`/sell?crypto=${crypto.symbol}`)}
                        >
                          Vendre
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderDeposit = () => (
    <div className="max-w-2xl mx-auto">
      <Card title="Dépôt de fonds" icon="download">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Choisissez une méthode</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {[
                { icon: 'creditCard', label: 'Carte bancaire', fee: '2.5%', time: 'Instant' },
                { icon: 'bank', label: 'Virement bancaire', fee: '0.5%', time: '1-3 jours' },
                { icon: 'wise', label: 'Wise Transfer', fee: '0.1%', time: '1-2 heures' }
              ].map((method, index) => (
                <button
                  key={index}
                  className="border border-gray-200 rounded-lg p-4 hover:border-[#D4AF37] hover:shadow-md transition-all text-center"
                >
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Icon name={method.icon} size="24px" />
                  </div>
                  <div className="font-medium text-gray-900 mb-1">{method.label}</div>
                  <div className="text-sm text-gray-600">Frais: {method.fee}</div>
                  <div className="text-sm text-gray-600">Délai: {method.time}</div>
                </button>
              ))}
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Dépôt Wise</h3>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Montant (USD)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="10000"
                    placeholder="5 - 10,000 USD"
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Wise
                  </label>
                  <input
                    type="email"
                    placeholder="votre@email.wise.com"
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Instructions de paiement
                </label>
                <textarea
                  rows={4}
                  placeholder="Indiquez ici toute information supplémentaire..."
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                ></textarea>
              </div>
              
              <Button variant="primary" className="w-full">
                Soumettre la demande
              </Button>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Icon name="warning" size="20px" color="#D97706" />
                  <div>
                    <h4 className="font-medium text-yellow-900 mb-1">Important</h4>
                    <p className="text-sm text-yellow-700">
                      • Montant minimum: 5 USD<br />
                      • Montant maximum: 10,000 USD<br />
                      • Traitement manuel sous 24 heures<br />
                      • Envoyez la preuve de paiement après transfert
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
  
  const renderWithdraw = () => (
    <div className="max-w-2xl mx-auto">
      <Card title="Retrait de fonds" icon="upload">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Sélectionnez une devise</h3>
            
            <div className="space-y-4">
              {Object.entries(walletData.currencies).map(([currency, data]) => (
                <div key={currency} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Icon name={currency.toLowerCase()} size="32px" />
                      <div>
                        <div className="font-medium text-gray-900">{currency}</div>
                        <div className="text-sm text-gray-500">Disponible: {formatCurrency(data.available, currency)}</div>
                      </div>
                    </div>
                    <Button
                      variant="primary"
                      size="small"
                      onClick={() => setShowWithdrawModal(true)}
                    >
                      Retirer
                    </Button>
                  </div>
                  
                  <div className="text-sm text-gray-600">
                    Frais: {currency === 'USD' ? '2.5%' : '3%'} • Délai: 1-3 jours ouvrables
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Retrait Crypto</h3>
            
            <div className="space-y-4">
              {walletData.cryptos.slice(0, 3).map((crypto) => (
                <div key={crypto.symbol} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon name={crypto.symbol.toLowerCase()} size="32px" />
                      <div>
                        <div className="font-medium text-gray-900">{crypto.name}</div>
                        <div className="text-sm text-gray-500">Solde: {crypto.balance} {crypto.symbol}</div>
                      </div>
                    </div>
                    <Button
                      variant="secondary"
                      size="small"
                      onClick={() => router.push(`/send?crypto=${crypto.symbol}`)}
                    >
                      Envoyer
                    </Button>
                  </div>
                </div>
              ))}
              
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => router.push('/send')}
              >
                Voir toutes les cryptos →
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
  
  const renderTransactions = () => (
    <Card title="Historique des transactions">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Date</th>
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Type</th>
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Actif</th>
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Montant</th>
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Statut</th>
              <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Détails</th>
            </tr>
          </thead>
          <tbody>
            {walletData.transactions.map((tx) => {
              const txIcon = getTransactionIcon(tx.type);
              
              return (
                <tr key={tx.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="text-sm text-gray-900">{tx.date}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full ${txIcon.bg} flex items-center justify-center`}>
                        <Icon name={txIcon.icon} size="16px" className={txIcon.color} />
                      </div>
                      <span className="capitalize">{tx.type}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      {tx.asset.includes('→') ? (
                        <>
                          <Icon name={tx.asset.split('→')[0].toLowerCase()} size="20px" />
                          <span className="font-medium">{tx.asset}</span>
                        </>
                      ) : (
                        <>
                          <Icon name={tx.asset.toLowerCase()} size="20px" />
                          <span className="font-medium">{tx.asset}</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-gray-900">
                      {tx.amount} {tx.asset}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                      tx.status === 'completed' ? 'bg-green-100 text-green-800' :
                      tx.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {tx.status === 'completed' ? 'Complété' : 
                       tx.status === 'pending' ? 'En attente' : 'Échoué'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button className="p-1 hover:bg-gray-100 rounded">
                      <Icon name="info" size="16px" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      
      <div className="mt-6 flex justify-between items-center">
        <div className="text-sm text-gray-600">
          Affichage de {walletData.transactions.length} transactions
        </div>
        <Button variant="ghost">
          Exporter en CSV
        </Button>
      </div>
    </Card>
  );
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />
        
        <div className="flex-1">
          <Header />
          
          <main className="p-6">
            {/* Titre et tabs */}
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Portefeuille</h1>
              
              <div className="border-b border-gray-200">
                <div className="flex space-x-8">
          