import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Sidebar from '../../components/layout/Sidebar';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';
import CryptoCard from '../../components/crypto/CryptoCard';
import PriceTicker from '../../components/crypto/PriceTicker';
import { formatCurrency } from '../../utils/currencies';
import { getAllCryptoPrices } from '../../services/binance';

const Dashboard = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [loading, setLoading] = useState(true);
  const [cryptoPrices, setCryptoPrices] = useState([]);
  
  // Données de démo
  const [userData] = useState({
    totalBalance: 12500.75,
    dailyChange: 2.45,
    portfolio: [
      { symbol: 'BTC', amount: 0.5, value: 35000 },
      { symbol: 'ETH', amount: 3.2, value: 9600 },
      { symbol: 'USDT', amount: 5000, value: 5000 },
      { symbol: 'BNB', amount: 5, value: 1500 }
    ],
    recentTransactions: [
      { id: 1, type: 'buy', crypto: 'BTC', amount: 0.1, value: 7000, date: '2024-01-15', status: 'completed' },
      { id: 2, type: 'sell', crypto: 'ETH', amount: 0.5, value: 1500, date: '2024-01-14', status: 'completed' },
      { id: 3, type: 'deposit', crypto: 'USD', amount: 10000, value: 10000, date: '2024-01-13', status: 'completed' },
      { id: 4, type: 'swap', crypto: 'BTC→ETH', amount: 0.2, value: 14000, date: '2024-01-12', status: 'pending' },
      { id: 5, type: 'withdraw', crypto: 'USD', amount: 500, value: 500, date: '2024-01-11', status: 'completed' }
    ]
  });
  
  useEffect(() => {
    loadCryptoPrices();
    
    // Refresh prices every 30 seconds
    const interval = setInterval(loadCryptoPrices, 30000);
    
    return () => clearInterval(interval);
  }, []);
  
  const loadCryptoPrices = async () => {
    try {
      const prices = await getAllCryptoPrices();
      setCryptoPrices(prices);
      setLoading(false);
    } catch (error) {
      console.error('Error loading crypto prices:', error);
    }
  };
  
  if (!user) {
    router.push('/auth/login');
    return null;
  }
  
  const quickActions = [
    { icon: 'buy', label: 'Acheter', color: 'bg-green-500', onClick: () => router.push('/buy') },
    { icon: 'sell', label: 'Vendre', color: 'bg-red-500', onClick: () => router.push('/sell') },
    { icon: 'send', label: 'Envoyer', color: 'bg-blue-500', onClick: () => router.push('/send') },
    { icon: 'receive', label: 'Recevoir', color: 'bg-purple-500', onClick: () => router.push('/receive') }
  ];
  
  const getTransactionIcon = (type) => {
    switch(type) {
      case 'buy': return { icon: 'buy', color: 'text-green-600', bg: 'bg-green-100' };
      case 'sell': return { icon: 'sell', color: 'text-red-600', bg: 'bg-red-100' };
      case 'deposit': return { icon: 'download', color: 'text-blue-600', bg: 'bg-blue-100' };
      case 'withdraw': return { icon: 'upload', color: 'text-orange-600', bg: 'bg-orange-100' };
      case 'swap': return { icon: 'exchange', color: 'text-purple-600', bg: 'bg-purple-100' };
      default: return { icon: 'transaction', color: 'text-gray-600', bg: 'bg-gray-100' };
    }
  };
  
  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <Sidebar />
        
        {/* Main content */}
        <div className="flex-1">
          <Header />
          
          <main className="p-6">
            {/* Welcome section */}
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                Bonjour, {user.email?.split('@')[0] || 'Utilisateur'} 👋
              </h1>
              <p className="text-gray-600">
                Bienvenue sur votre tableau de bord Pay Fusion
              </p>
            </div>
            
            {/* Solde principal */}
            <Card 
              variant="primary" 
              icon="wallet" 
              title="Solde total" 
              subtitle="Portefeuille complet"
              className="mb-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-4xl font-bold mb-2">
                    {formatCurrency(userData.totalBalance, 'USD')}
                  </div>
                  <div className={`flex items-center gap-2 ${userData.dailyChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    <Icon name={userData.dailyChange >= 0 ? 'arrow-up' : 'arrow-down'} size="16px" />
                    <span className="font-medium">
                      {userData.dailyChange >= 0 ? '+' : ''}{userData.dailyChange}%
                    </span>
                    <span className="text-sm text-white/80">aujourd'hui</span>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <Button variant="primary" icon="plus">
                    Dépôt
                  </Button>
                  <Button variant="secondary" icon="send">
                    Retrait
                  </Button>
                </div>
              </div>
            </Card>
            
            {/* Quick actions */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={action.onClick}
                  className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow text-center"
                >
                  <div className={`w-12 h-12 ${action.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                    <Icon name={action.icon} size="24px" color="#FFFFFF" />
                  </div>
                  <div className="font-medium text-gray-900">{action.label}</div>
                </button>
              ))}
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* Vos cryptos */}
              <div className="lg:col-span-2">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Vos cryptos</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userData.portfolio.map((crypto, index) => (
                    <div key={index} className="bg-white rounded-xl border border-gray-200 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <Icon name={crypto.symbol.toLowerCase()} size="32px" />
                          <div>
                            <div className="font-semibold text-gray-900">{crypto.symbol}</div>
                            <div className="text-sm text-gray-500">{crypto.amount} {crypto.symbol}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-gray-900">
                            {formatCurrency(crypto.value, 'USD')}
                          </div>
                          <div className="text-sm text-gray-500">
                            {(crypto.value / userData.totalBalance * 100).toFixed(1)}%
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="primary"
                          size="small"
                          className="flex-1"
                          onClick={() => router.push(`/buy?crypto=${crypto.symbol}`)}
                        >
                          Acheter
                        </Button>
                        <Button
                          variant="secondary"
                          size="small"
                          className="flex-1"
                          onClick={() => router.push(`/sell?crypto=${crypto.symbol}`)}
                        >
                          Vendre
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Marché en direct */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Marché en direct</h2>
                <PriceTicker />
              </div>
            </div>
            
            {/* Activité récente */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Activité récente</h2>
                <Button
                  variant="ghost"
                  size="small"
                  onClick={() => router.push('/history')}
                >
                  Voir tout →
                </Button>
              </div>
              
              <Card>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Date</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Type</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Crypto</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Montant</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Statut</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {userData.recentTransactions.map((tx) => {
                        const txIcon = getTransactionIcon(tx.type);
                        
                        return (
                          <tr key={tx.id} className="border-b border-gray-100 hover:bg-gray-50">
                            <td className="py-3 px-4">
                              <div className="text-sm text-gray-900">{tx.date}</div>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2">
                                <div className={`w-8 h-8 rounded-full ${txIcon.bg} flex items-center justify-center`}>
                                  <Icon name={txIcon.icon} size="16px" className={txIcon.color} />
                                </div>
                                <span className="capitalize">{tx.type}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2">
                                <Icon name={tx.crypto.toLowerCase().split('→')[0]} size="20px" />
                                <span className="font-medium">{tx.crypto}</span>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <div className="font-semibold text-gray-900">
                                {formatCurrency(tx.value, 'USD')}
                              </div>
                              <div className="text-sm text-gray-500">
                                {tx.amount} {tx.crypto}
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(tx.status)}`}>
                                {tx.status === 'completed' ? 'Complété' : 
                                 tx.status === 'pending' ? 'En attente' : 'Échoué'}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <button className="p-1 hover:bg-gray-100 rounded">
                                <Icon name="info" size="16px" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          </main>
          
          <Footer />
        </div>
      </div>
      
      {/* Tools Super Admin */}
      {isGod && <GodTools />}
    </div>
  );
};

export default Dashboard;