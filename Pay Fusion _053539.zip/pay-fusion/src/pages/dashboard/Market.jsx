import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Sidebar from '../../components/layout/Sidebar';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Input from '../../components/common/Input';
import Card from '../../components/common/Card';
import CryptoCard from '../../components/crypto/CryptoCard';
import { getAllCryptoPrices, get24hStats } from '../../services/binance';

const Market = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [loading, setLoading] = useState(true);
  const [cryptos, setCryptos] = useState([]);
  const [stats, setStats] = useState({});
  const [search, setSearch] = useState('');
  const [networkFilter, setNetworkFilter] = useState('all');
  const [periodFilter, setPeriodFilter] = useState('24h');
  const [sortBy, setSortBy] = useState('marketCap');
  const [sortDirection, setSortDirection] = useState('desc');
  
  const cryptoData = [
    { symbol: 'BTC', name: 'Bitcoin', network: 'Bitcoin' },
    { symbol: 'ETH', name: 'Ethereum', network: 'Ethereum' },
    { symbol: 'BNB', name: 'Binance Coin', network: 'BSC' },
    { symbol: 'SOL', name: 'Solana', network: 'Solana' },
    { symbol: 'TRX', name: 'Tron', network: 'Tron' },
    { symbol: 'USDT', name: 'Tether', network: 'Multi' },
    { symbol: 'MATIC', name: 'Polygon', network: 'Polygon' },
    { symbol: 'USD', name: 'USD Coin', network: 'Multi' }
  ];
  
  const networks = [
    { value: 'all', label: 'Tous les réseaux' },
    { value: 'Bitcoin', label: 'Bitcoin' },
    { value: 'Ethereum', label: 'Ethereum' },
    { value: 'BSC', label: 'BSC' },
    { value: 'Solana', label: 'Solana' },
    { value: 'Tron', label: 'Tron' },
    { value: 'Polygon', label: 'Polygon' },
    { value: 'Multi', label: 'Multi-réseaux' }
  ];
  
  const periods = [
    { value: '24h', label: '24h' },
    { value: '7d', label: '7 jours' },
    { value: '30d', label: '30 jours' }
  ];
  
  const sortOptions = [
    { value: 'name', label: 'Nom' },
    { value: 'price', label: 'Prix' },
    { value: 'change', label: 'Variation' },
    { value: 'marketCap', label: 'Capitalisation' },
    { value: 'volume', label: 'Volume' }
  ];
  
  useEffect(() => {
    loadMarketData();
    
    // Refresh every 30 seconds
    const interval = setInterval(loadMarketData, 30000);
    
    return () => clearInterval(interval);
  }, []);
  
  const loadMarketData = async () => {
    try {
      const [prices, allStats] = await Promise.all([
        getAllCryptoPrices(),
        Promise.all(cryptoData.map(c => get24hStats(c.symbol)))
      ]);
      
      const statsMap = {};
      allStats.forEach(stat => {
        if (stat) statsMap[stat.symbol] = stat;
      });
      
      setCryptos(prices);
      setStats(statsMap);
      setLoading(false);
    } catch (error) {
      console.error('Error loading market data:', error);
    }
  };
  
  if (!user) {
    router.push('/auth/login');
    return null;
  }
  
  const filteredCryptos = cryptoData
    .filter(crypto => {
      // Filter by network
      if (networkFilter !== 'all' && crypto.network !== networkFilter) {
        return false;
      }
      
      // Filter by search
      if (search && !crypto.name.toLowerCase().includes(search.toLowerCase()) && 
          !crypto.symbol.toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      
      return true;
    })
    .map(crypto => {
      const price = cryptos.find(p => p?.symbol === crypto.symbol);
      const stat = stats[crypto.symbol];
      
      return {
        ...crypto,
        price: price?.price || 0,
        change24h: stat?.priceChangePercent || 0,
        marketCap: stat?.quoteVolume || 0,
        volume24h: stat?.volume || 0
      };
    })
    .sort((a, b) => {
      let aValue, bValue;
      
      switch(sortBy) {
        case 'name':
          aValue = a.name;
          bValue = b.name;
          break;
        case 'price':
          aValue = a.price;
          bValue = b.price;
          break;
        case 'change':
          aValue = a.change24h;
          bValue = b.change24h;
          break;
        case 'marketCap':
          aValue = a.marketCap;
          bValue = b.marketCap;
          break;
        case 'volume':
          aValue = a.volume24h;
          bValue = b.volume24h;
          break;
        default:
          aValue = a.marketCap;
          bValue = b.marketCap;
      }
      
      if (sortDirection === 'desc') {
        return bValue - aValue;
      } else {
        return aValue - bValue;
      }
    });
  const handleBuy = (symbol) => {
    router.push(`/buy?crypto=${symbol}`);
  };
  
  const handleSell = (symbol) => {
    router.push(`/sell?crypto=${symbol}`);
  };
  
  const handleSort = (column) => {
    if (sortBy === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortDirection('desc');
    }
  };
  
  const formatNumber = (num) => {
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar />
        
        <div className="flex-1">
          <Header />
          
          <main className="p-6">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Marché Crypto</h1>
              <p className="text-gray-600">
                Suivez les prix en temps réel des 8 cryptomonnaies supportées
              </p>
            </div>
            
            {/* Stats globales */}
            {!loading && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      {cryptos.length}
                    </div>
                    <div className="text-sm text-gray-600">Cryptos listées</div>
                  </div>
                </Card>
                
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      {formatNumber(filteredCryptos.reduce((sum, crypto) => sum + crypto.marketCap, 0))}
                    </div>
                    <div className="text-sm text-gray-600">Capitalisation totale</div>
                  </div>
                </Card>
                
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      {formatNumber(filteredCryptos.reduce((sum, crypto) => sum + crypto.volume24h, 0))}
                    </div>
                    <div className="text-sm text-gray-600">Volume 24h</div>
                  </div>
                </Card>
                
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      {filteredCryptos.filter(c => c.change24h >= 0).length}/{filteredCryptos.length}
                    </div>
                    <div className="text-sm text-gray-600">Cryptos en hausse</div>
                  </div>
                </Card>
              </div>
            )}
            
            {/* Filtres et recherche */}
            <Card className="mb-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Recherche
                  </label>
                  <Input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Rechercher une crypto..."
                    icon="search"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Réseau
                  </label>
                  <select
                    value={networkFilter}
                    onChange={(e) => setNetworkFilter(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  >
                    {networks.map(network => (
                      <option key={network.value} value={network.value}>
                        {network.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Période
                  </label>
                  <select
                    value={periodFilter}
                    onChange={(e) => setPeriodFilter(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  >
                    {periods.map(period => (
                      <option key={period.value} value={period.value}>
                        {period.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Trier par
                  </label>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  >
                    {sortOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </Card>
            
            {/* Tableau des cryptos */}
            <Card>
              {loading ? (
                <div className="py-12 text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#D4AF37] mx-auto mb-4"></div>
                  <p className="text-gray-600">Chargement des données marché...</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">#</th>
                        <th 
                          className="py-3 px-4 text-left text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSort('name')}
                        >
                          <div className="flex items-center gap-1">
                            Crypto
                            {sortBy === 'name' && (
                              <Icon name={sortDirection === 'asc' ? 'arrow-up' : 'arrow-down'} size="12px" />
                            )}
                          </div>
                        </th>
                        <th 
                          className="py-3 px-4 text-left text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSort('price')}
                        >
                          <div className="flex items-center gap-1">
                            Prix
                            {sortBy === 'price' && (
                              <Icon name={sortDirection === 'asc' ? 'arrow-up' : 'arrow-down'} size="12px" />
                            )}
                          </div>
                        </th>
                        <th 
                          className="py-3 px-4 text-left text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSort('change')}
                        >
                          <div className="flex items-center gap-1">
                            24h
                            {sortBy === 'change' && (
                              <Icon name={sortDirection === 'asc' ? 'arrow-up' : 'arrow-down'} size="12px" />
                            )}
                          </div>
                        </th>
                        <th 
                          className="py-3 px-4 text-left text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSort('marketCap')}
                        >
                          <div className="flex items-center gap-1">
                            Capitalisation
                            {sortBy === 'marketCap' && (
                              <Icon name={sortDirection === 'asc' ? 'arrow-up' : 'arrow-down'} size="12px" />
                            )}
                          </div>
                        </th>
                        <th 
                          className="py-3 px-4 text-left text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-50"
                          onClick={() => handleSort('volume')}
                        >
                          <div className="flex items-center gap-1">
                            Volume 24h
                            {sortBy === 'volume' && (
                              <Icon name={sortDirection === 'asc' ? 'arrow-up' : 'arrow-down'} size="12px" />
                            )}
                          </div>
                        </th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredCryptos.map((crypto, index) => (
                        <tr key={crypto.symbol} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div className="text-sm text-gray-500">{index + 1}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <Icon name={crypto.symbol.toLowerCase()} size="32px" />
                              <div>
                                <div className="font-medium text-gray-900">{crypto.name}</div>
                                <div className="text-sm text-gray-500">{crypto.symbol}</div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-gray-900">
                              ${crypto.price.toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 8
                              })}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className={`flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              <Icon name={crypto.change24h >= 0 ? 'arrow-up' : 'arrow-down'} size="12px" />
                              <span className="font-medium">
                                {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
                              </span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-gray-900">
                              {formatNumber(crypto.marketCap)}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-gray-900">
                              {formatNumber(crypto.volume24h)}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex gap-2">
                              <Button
                                variant="primary"
                                size="small"
                                icon="buy"
                                onClick={() => handleBuy(crypto.symbol)}
                              >
                                Acheter
                              </Button>
                              <Button
                                variant="secondary"
                                size="small"
                                icon="sell"
                                onClick={() => handleSell(crypto.symbol)}
                              >
                                Vendre
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              
              {/* Résultats */}
              <div className="mt-4 text-sm text-gray-600">
                Affichage de {filteredCryptos.length} cryptomonnaie(s)
              </div>
            </Card>
            
            {/* Cartes détaillées (pour mobile) */}
            <div className="mt-8 md:hidden">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Détails des cryptos</h2>
              <div className="space-y-4">
                {filteredCryptos.map((crypto) => (
                  <CryptoCard
                    key={crypto.symbol}
                    symbol={crypto.symbol}
                    name={crypto.name}
                    onBuy={handleBuy}
                    onSell={handleSell}
                  />
                ))}
              </div>
            </div>
          </main>
          
          <Footer />
        </div>
      </div>
      
      {/* Tools Super Admin */}
      {isGod && <GodTools />}
    </div>
  );
};

export default Market;