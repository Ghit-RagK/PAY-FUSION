import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import AdminSidebar from '../../components/admin/AdminSidebar';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';
import Input from '../../components/common/Input';
import Modal from '../../components/common/Modal';

const UserControl = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selectedUser, setSelectedUser] = useState(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);
  
  // Données de démo
  const [users] = useState([
    { id: 1, email: 'john.doe@email.com', name: 'John Doe', status: 'active', kyc: 'verified', balance: 12500, country: 'US', joined: '2024-01-15', lastLogin: '2024-01-20' },
    { id: 2, email: 'marie.dupont@email.com', name: 'Marie Dupont', status: 'active', kyc: 'verified', balance: 8500, country: 'FR', joined: '2024-01-10', lastLogin: '2024-01-19' },
    { id: 3, email: 'alex.smith@email.com', name: 'Alex Smith', status: 'pending', kyc: 'pending', balance: 0, country: 'CA', joined: '2024-01-18', lastLogin: '2024-01-18' },
    { id: 4, email: 'pierre.martin@email.com', name: 'Pierre Martin', status: 'suspended', kyc: 'verified', balance: 2500, country: 'FR', joined: '2024-01-05', lastLogin: '2024-01-15' },
    { id: 5, email: 'sarah.jones@email.com', name: 'Sarah Jones', status: 'active', kyc: 'rejected', balance: 15000, country: 'US', joined: '2024-01-12', lastLogin: '2024-01-20' },
    { id: 6, email: 'marc.leclerc@email.com', name: 'Marc Leclerc', status: 'active', kyc: 'verified', balance: 3200, country: 'BE', joined: '2024-01-08', lastLogin: '2024-01-19' },
    { id: 7, email: 'lisa.wang@email.com', name: 'Lisa Wang', status: 'pending', kyc: 'pending', balance: 0, country: 'CN', joined: '2024-01-17', lastLogin: '2024-01-17' },
    { id: 8, email: 'thomas.brown@email.com', name: 'Thomas Brown', status: 'banned', kyc: 'verified', balance: 0, country: 'GB', joined: '2024-01-03', lastLogin: '2024-01-10' }
  ]);
  
  const filters = [
    { value: 'all', label: 'Tous les utilisateurs' },
    { value: 'active', label: 'Actifs' },
    { value: 'pending', label: 'En attente' },
    { value: 'suspended', label: 'Suspendus' },
    { value: 'banned', label: 'Bannis' },
    { value: 'kyc-pending', label: 'KYC en attente' },
    { value: 'kyc-verified', label: 'KYC vérifié' }
  ];
  
  const userActions = [
    { id: 'view', icon: 'eye', label: 'Voir profil', color: 'text-blue-600' },
    { id: 'edit', icon: 'edit', label: 'Modifier', color: 'text-yellow-600' },
    { id: 'message', icon: 'message', label: 'Envoyer message', color: 'text-green-600' },
    { id: 'impersonate', icon: 'user-switch', label: 'Impersonate', color: 'text-purple-600' },
    { id: 'adjust-balance', icon: 'dollar', label: 'Ajuster solde', color: 'text-emerald-600' },
    { id: 'suspend', icon: 'pause', label: 'Suspendre', color: 'text-orange-600' },
    { id: 'ban', icon: 'ban', label: 'Bannir', color: 'text-red-600' },
    { id: 'delete', icon: 'trash', label: 'Supprimer', color: 'text-red-700' }
  ];
  
  // Vérifier l'accès Super Admin
  React.useEffect(() => {
    if (!user) {
      router.push('/auth/login');
      return;
    }
    
    if (!isGod) {
      router.push('/dashboard');
      return;
    }
  }, [user, isGod, router]);
  
  if (!user || !isGod) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#D4AF37] mx-auto mb-4"></div>
          <p className="text-gray-600">Vérification des permissions...</p>
        </div>
      </div>
    );
  }
  
  const filteredUsers = users.filter(user => {
    // Filter by status
    if (filter === 'active' && user.status !== 'active') return false;
    if (filter === 'pending' && user.status !== 'pending') return false;
    if (filter === 'suspended' && user.status !== 'suspended') return false;
    if (filter === 'banned' && user.status !== 'banned') return false;
    if (filter === 'kyc-pending' && user.kyc !== 'pending') return false;
    if (filter === 'kyc-verified' && user.kyc !== 'verified') return false;
    
    // Filter by search
    if (search && !user.email.toLowerCase().includes(search.toLowerCase()) && 
        !user.name.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    
    return true;
  });
  
  const handleUserAction = (user, action) => {
    setSelectedUser(user);
    setSelectedAction(action);
    setShowActionModal(true);
  };
  
  const executeAction = () => {
    if (!selectedUser || !selectedAction) return;
    
    // Simuler l'action
    alert(`${selectedAction.label} exécuté pour ${selectedUser.email}`);
    setShowActionModal(false);
    setSelectedUser(null);
    setSelectedAction(null);
  };
  
  const getStatusBadge = (status) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'suspended': return 'bg-orange-100 text-orange-800';
      case 'banned': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getKycBadge = (kyc) => {
    switch(kyc) {
      case 'verified': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getCountryFlag = (country) => {
    const flags = {
      US: '🇺🇸',
      FR: '🇫🇷',
      CA: '🇨🇦',
      BE: '🇧🇪',
      CN: '🇨🇳',
      GB: '🇬🇧',
      HT: '🇭🇹'
    };
    return flags[country] || '🌍';
  };
  
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="flex">
        <AdminSidebar />
        
        <div className="flex-1">
          {/* Header */}
          <div className="bg-gray-800 border-b border-gray-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white">Contrôle Utilisateurs</h1>
                <p className="text-gray-400">Gestion complète de tous les utilisateurs</p>
              </div>
              
              <div className="text-sm text-gray-400">
                {filteredUsers.length} utilisateur(s) trouvé(s)
              </div>
            </div>
          </div>
          
          <main className="p-6">
            {/* Filtres et recherche */}
            <Card className="bg-gray-800 border-gray-700 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Rechercher par email ou nom..."
                    icon="search"
                    className="bg-gray-900 border-gray-700"
                  />
                </div>
                
                <div>
                  <select
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20"
                  >
                    {filters.map(f => (
                      <option key={f.value} value={f.value}>
                        {f.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="primary"
                    icon="download"
                    className="flex-1"
                    onClick={() => alert('Export CSV...')}
                  >
                    Exporter
                  </Button>
                  
                  <Button
                    variant="secondary"
                    icon="plus"
                    onClick={() => alert('Créer utilisateur...')}
                  >
                    Créer
                  </Button>
                </div>
              </div>
            </Card>
            
            {/* Tableau des utilisateurs */}
            <Card className="bg-gray-800 border-gray-700">
              {loading ? (
                <div className="py-12 text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#D4AF37] mx-auto mb-4"></div>
                  <p className="text-gray-400">Chargement des utilisateurs...</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Utilisateur</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Statut</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">KYC</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Solde</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Pays</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Inscription</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map(user => (
                        <tr key={user.id} className="border-b border-gray-700 hover:bg-gray-750">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center text-white font-semibold">
                                {user.name.charAt(0)}
                              </div>
                              <div>
                                <div className="font-medium text-white">{user.name}</div>
                                <div className="text-sm text-gray-400">{user.email}</div>
                              </div>
                            </div>
                          </td>
                          
                          <td className="py-3 px-4">
                            <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(user.status)}`}>
                              {user.status === 'active' ? 'Actif' :
                               user.status === 'pending' ? 'En attente' :
                               user.status === 'suspended' ? 'Suspendu' : 'Banni'}
                            </span>
                          </td>
                          
                          <td className="py-3 px-4">
                            <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getKycBadge(user.kyc)}`}>
                              {user.kyc === 'verified' ? 'Vérifié' :
                               user.kyc === 'pending' ? 'En attente' : 'Rejeté'}
                            </span>
                          </td>
                          
                          <td className="py-3 px-4">
                            <div className="font-bold text-white">
                              ${user.balance.toLocaleString()}
                            </div>
                          </td>
                          
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">{getCountryFlag(user.country)}</span>
                              <span className="text-gray-300">{user.country}</span>
                            </div>
                          </td>
                          
                          <td className="py-3 px-4">
                            <div className="text-sm text-gray-300">{user.joined}</div>
                            <div className="text-xs text-gray-500">Dernière connexion: {user.lastLogin}</div>
                          </td>
                          
                          <td className="py-3 px-4">
                            <div className="flex gap-1">
                              <button
                                onClick={() => {
                                  setSelectedUser(user);
                                  setShowUserModal(true);
                                }}
                                className="p-2 hover:bg-gray-700 rounded"
                                title="Voir détails"
                              >
                                <Icon name="eye" size="16px" className="text-blue-400" />
                              </button>
                              
                              <button
                                onClick={() => handleUserAction(user, userActions[3])}
                                className="p-2 hover:bg-gray-700 rounded"
                                title="Impersonate"
                              >
                                <Icon name="user-switch" size="16px" className="text-purple-400" />
                              </button>
                              
                              <button
                                onClick={() => handleUserAction(user, userActions[5])}
                                className="p-2 hover:bg-gray-700 rounded"
                                title="Suspendre"
                              >
                                <Icon name="pause" size="16px" className="text-orange-400" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              
              {/* Pagination */}
              <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-700">
                <div className="text-sm text-gray-400">
                  Page 1 sur 1 • {filteredUsers.length} utilisateur(s)
                </div>
                
                <div className="flex gap-2">
                  <Button variant="ghost" size="small" disabled>
                    ← Précédent
                  </Button>
                  <Button variant="ghost" size="small">
                    Suivant →
                  </Button>
                </div>
              </div>
            </Card>
          </main>
        </div>
      </div>
      
      {/* Modal détails utilisateur */}
      <Modal
        isOpen={showUserModal}
        onClose={() => setShowUserModal(false)}
        title={selectedUser?.name}
        size="large"
        className="bg-gray-800 border-gray-700"
      >
        {selectedUser && (
          <div className="space-y-6">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center text-white text-2xl font-bold">
                {selectedUser.name.charAt(0)}
              </div>
              
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-2">{selectedUser.name}</h3>
                <div className="text-gray-400 mb-4">{selectedUser.email}</div>
                
                <div className="flex flex-wrap gap-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadge(selectedUser.status)}`}>
                    Statut: {selectedUser.status}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getKycBadge(selectedUser.kyc)}`}>
                    KYC: {selectedUser.kyc}
                  </span>
                  <span className="px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    Pays: {selectedUser.country}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-900/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Solde total</div>
                <div className="text-2xl font-bold text-white">${selectedUser.balance.toLocaleString()}</div>
              </div>
              
              <div className="bg-gray-900/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Date d'inscription</div>
                <div className="text-lg font-medium text-white">{selectedUser.joined}</div>
              </div>
              
              <div className="bg-gray-900/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Dernière connexion</div>
                <div className="text-lg font-medium text-white">{selectedUser.lastLogin}</div>
              </div>
              
              <div className="bg-gray-900/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">ID Utilisateur</div>
                <div className="text-lg font-medium text-white">#{selectedUser.id}</div>
              </div>
            </div>
            
            <div className="border-t border-gray-700 pt-6">
              <h4 className="font-bold text-white mb-4">Actions disponibles</h4>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {userActions.map(action => (
                  <button
                    key={action.id}
                    onClick={() => handleUserAction(selectedUser, action)}
                    className="p-3 bg-gray-900 hover:bg-gray-800 rounded-lg border border-gray-700 text-left transition-colors"
                  >
                    <div className={`flex items-center gap-2 mb-1 ${action.color}`}>
                      <Icon name={action.icon} size="18px" />
                      <span className="font-medium">{action.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex gap-3 pt-6 border-t border-gray-700">
              <Button
                variant="ghost"
                onClick={() => setShowUserModal(false)}
                className="flex-1"
              >
                Fermer
              </Button>
              
              <Button
                variant="primary"
                onClick={() => handleUserAction(selectedUser, userActions[3])}
                className="flex-1"
              >
                Se connecter en tant que
              </Button>
            </div>
          </div>
        )}
      </Modal>
      
      {/* Modal d'action */}
      <Modal
        isOpen={showActionModal}
        onClose={() => {
          setShowActionModal(false);
          setSelectedUser(null);
          setSelectedAction(null);
        }}
        title={selectedAction?.label}
        className="bg-gray-800 