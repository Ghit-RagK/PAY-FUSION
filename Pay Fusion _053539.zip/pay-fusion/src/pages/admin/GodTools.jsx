import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../common/Icon';
import Button from '../common/Button';
import Modal from '../common/Modal';

const GodTools = () => {
  const { isGod } = useAuth();
  const [editMode, setEditMode] = useState(false);
  const [showNuclearModal, setShowNuclearModal] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);
  
  if (!isGod) return null;
  
  const nuclearActions = [
    {
      id: 'maintenance',
      title: 'Mode Maintenance',
      description: 'Activer le mode maintenance pour tous les utilisateurs',
      icon: 'tools',
      level: 'warning',
      confirmations: 1
    },
    {
      id: 'emergency-stop',
      title: 'Arrêt d\'Urgence',
      description: 'Arrêter toutes les transactions immédiatement',
      icon: 'alert',
      level: 'danger',
      confirmations: 2
    },
    {
      id: 'reset-prices',
      title: 'Réinitialiser les Prix',
      description: 'Forcer la réinitialisation des prix depuis Binance',
      icon: 'refresh',
      level: 'warning',
      confirmations: 1
    },
    {
      id: 'purge-cache',
      title: 'Purge du Cache',
      description: 'Vider tous les caches système',
      icon: 'trash',
      level: 'info',
      confirmations: 1
    },
    {
      id: 'backup-now',
      title: 'Backup Immédiat',
      description: 'Créer un backup complet du système',
      icon: 'cloud-upload',
      level: 'info',
      confirmations: 1
    },
    {
      id: 'restart-services',
      title: 'Redémarrer Services',
      description: 'Redémarrer tous les services backend',
      icon: 'power',
      level: 'warning',
      confirmations: 2
    }
  ];
  
  const handleNuclearAction = (action) => {
    setSelectedAction(action);
    setShowNuclearModal(true);
  };
  
  const executeNuclearAction = () => {
    if (!selectedAction) return;
    
    // Ici, vous implémenteriez l'action réelle
    console.log(`Executing nuclear action: ${selectedAction.id}`);
    
    // Simuler l'action
    alert(`Action "${selectedAction.title}" exécutée avec succès!`);
    
    setShowNuclearModal(false);
    setSelectedAction(null);
  };
  
  return (
    <>
      {/* Barre d'outils flottante */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className="flex flex-col items-end gap-3">
          {/* Bouton principal */}
          <Button
            variant="primary"
            size="large"
            icon="crown"
            onClick={() => setEditMode(!editMode)}
            className="shadow-2xl"
          >
            MODE DIEU {editMode ? 'ACTIF' : 'INACTIF'}
          </Button>
          
          {/* Menu étendu */}
          {editMode && (
            <div className="bg-white rounded-xl shadow-2xl border border-gray-200 p-4 min-w-[300px]">
              <div className="mb-4">
                <h3 className="font-semibold text-gray-900 mb-2">Outils Rapides</h3>
                
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <Button
                    variant="secondary"
                    size="small"
                    icon="edit"
                    onClick={() => window.location.href = '/god/editor'}
                  >
                    Éditeur
                  </Button>
                  
                  <Button
                    variant="secondary"
                    size="small"
                    icon="users"
                    onClick={() => window.location.href = '/god/users'}
                  >
                    Utilisateurs
                  </Button>
                  
                  <Button
                    variant="secondary"
                    size="small"
                    icon="transactions"
                    onClick={() => window.location.href = '/god/transactions'}
                  >
                    Transactions
                  </Button>
                  
                  <Button
                    variant="secondary"
                    size="small"
                    icon="database"
                    onClick={() => window.location.href = '/god/database'}
                  >
                    Base de données
                  </Button>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-4">
                <h3 className="font-semibold text-gray-900 mb-2">Fonctions Nucléaires</h3>
                
                <div className="space-y-2">
                  {nuclearActions.map((action) => (
                    <button
                      key={action.id}
                      onClick={() => handleNuclearAction(action)}
                      className={`
                        w-full flex items-center justify-between p-3 rounded-lg
                        transition-all duration-200
                        ${action.level === 'danger' 
                          ? 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
                          : action.level === 'warning'
                          ? 'bg-yellow-50 hover:bg-yellow-100 text-yellow-700 border border-yellow-200'
                          : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200'
                        }
                      `}
                    >
                      <div className="flex items-center gap-3">
                        <Icon name={action.icon} size="18px" />
                        <div className="text-left">
                          <div className="font-medium">{action.title}</div>
                          <div className="text-xs opacity-75">{action.description}</div>
                        </div>
                      </div>
                      
                      <div className="text-xs font-semibold">
                        {action.confirmations} {action.confirmations === 1 ? 'confirmation' : 'confirmations'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mt-4 text-center">
                <Button
                  variant="ghost"
                  size="small"
                  onClick={() => window.location.href = '/god/dashboard'}
                  className="w-full"
                >
                  Accéder au Dashboard Complet
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Modal de confirmation pour actions nucléaires */}
      <Modal
        isOpen={showNuclearModal}
        onClose={() => {
          setShowNuclearModal(false);
          setSelectedAction(null);
        }}
        title={selectedAction?.title}
        size="medium"
      >
        {selectedAction && (
          <div className="space-y-4">
            <div className={`p-4 rounded-lg ${
              selectedAction.level === 'danger' 
                ? 'bg-red-50 border border-red-200'
                : selectedAction.level === 'warning'
                ? 'bg-yellow-50 border border-yellow-200'
                : 'bg-blue-50 border border-blue-200'
            }`}>
              <div className="flex items-start gap-3">
                <Icon 
                  name={selectedAction.icon} 
                  size="24px" 
                  color={
                    selectedAction.level === 'danger' 
                      ? '#DC2626'
                      : selectedAction.level === 'warning'
                      ? '#D97706'
                      : '#2563EB'
                  }
                />
                
                <div>
                  <h4 className="font-semibold mb-1">Attention !</h4>
                  <p className="text-sm">{selectedAction.description}</p>
                  <p className="text-sm mt-2 font-medium">
                    Cette action nécessite {selectedAction.confirmations} confirmation(s).
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium mb-2">Confirmation requise:</h4>
              
              {selectedAction.confirmations === 1 ? (
                <div className="flex items-center gap-3 p-3 bg-white rounded border">
                  <input type="checkbox" id="confirm1" className="w-5 h-5" />
                  <label htmlFor="confirm1" className="text-sm">
                    Je confirme vouloir exécuter cette action
                  </label>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-white rounded border">
                    <input type="checkbox" id="confirm1" className="w-5 h-5" />
                    <label htmlFor="confirm1" className="text-sm">
                      Je comprends les conséquences de cette action
                    </label>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-white rounded border">
                    <input type="checkbox" id="confirm2" className="w-5 h-5" />
                    <label htmlFor="confirm2" className="text-sm">
                      J'ai vérifié qu'aucun utilisateur n'est impacté
                    </label>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex gap-3">
              <Button
                variant="ghost"
                onClick={() => {
                  setShowNuclearModal(false);
                  setSelectedAction(null);
                }}
                className="flex-1"
              >
                Annuler
              </Button>
              
              <Button
                variant={selectedAction.level === 'danger' ? 'danger' : 'primary'}
                onClick={executeNuclearAction}
                className="flex-1"
              >
                Exécuter l'action
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

export default GodTools;