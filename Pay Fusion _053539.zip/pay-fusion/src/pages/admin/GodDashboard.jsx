import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import AdminSidebar from '../../components/admin/AdminSidebar';
import GodTools from '../../components/admin/GodTools';
import Icon from '../../components/common/Icon';
import Button from '../../components/common/Button';
import Card from '../../components/common/Card';
import Modal from '../../components/common/Modal';

const GodDashboard = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showNuclearModal, setShowNuclearModal] = useState(false);
  const [nuclearAction, setNuclearAction] = useState(null);
  
  // Données de statistiques
  const [stats] = useState({
    totalUsers: 1250,
    activeUsers: 842,
    totalTransactions: 5489,
    pendingKYC: 23,
    pendingTransactions: 15,
    dailyVolume: 1250000,
    totalRevenue: 12500,
    systemHealth: 98.5
  });
  
  // Activité récente
  const [recentActivity] = useState([
    { id: 1, user: 'john@email.com', action: 'Connexion', time: '2 min', ip: '192.168.1.1' },
    { id: 2, user: 'marie@email.com', action: 'Achat BTC', amount: '0.5 BTC', time: '5 min' },
    { id: 3, user: 'admin', action: 'Validation KYC', userAffected: 'pierre@email.com', time: '10 min' },
    { id: 4, user: 'system', action: 'Backup automatique', time: '1 h' },
    { id: 5, user: 'alex@email.com', action: 'Tentative échouée', type: 'Connexion', time: '2 h' }
  ]);
  
  // Alertes système
  const [alerts] = useState([
    { id: 1, type: 'warning', message: '23 demandes KYC en attente', priority: 'medium' },
    { id: 2, type: 'danger', message: '15 transactions nécessitent validation', priority: 'high' },
    { id: 3, type: 'info', message: 'Backup programmé à 2h00', priority: 'low' },
    { id: 4, type: 'warning', message: 'Utilisation CPU à 85%', priority: 'medium' }
  ]);
  
  // Actions nucléaires
  const nuclearActions = [
    {
      id: 'maintenance',
      title: 'Mode Maintenance',
      description: 'Activer le mode maintenance pour tous les utilisateurs',
      icon: 'tools',
      color: 'text-yellow-600',
      bg: 'bg-yellow-100',
      level: 'warning'
    },
    {
      id: 'emergency-stop',
      title: 'Arrêt d\'Urgence',
      description: 'Arrêter toutes les transactions immédiatement',
      icon: 'alert',
      color: 'text-red-600',
      bg: 'bg-red-100',
      level: 'danger'
    },
    {
      id: 'reset-prices',
      title: 'Réinitialiser Prix',
      description: 'Forcer sync des prix depuis Binance',
      icon: 'refresh',
      color: 'text-blue-600',
      bg: 'bg-blue-100',
      level: 'info'
    },
    {
      id: 'purge-cache',
      title: 'Purge Cache',
      description: 'Vider tous les caches système',
      icon: 'trash',
      color: 'text-purple-600',
      bg: 'bg-purple-100',
      level: 'warning'
    }
  ];
  
  // Vérifier l'accès Super Admin
  useEffect(() => {
    if (!user) {
      router.push('/auth/login');
      return;
    }
    
    if (!isGod) {
      router.push('/dashboard');
      return;
    }
  }, [user, isGod, router]);
  
  if (!user || !isGod) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#D4AF37] mx-auto mb-4"></div>
          <p className="text-gray-600">Vérification des permissions...</p>
        </div>
      </div>
    );
  }
  
  const handleNuclearAction = (action) => {
    setNuclearAction(action);
    setShowNuclearModal(true);
  };
  
  const executeNuclearAction = () => {
    if (!nuclearAction) return;
    
    // Simuler l'exécution
    console.log(`Executing: ${nuclearAction.id}`);
    alert(`Action "${nuclearAction.title}" exécutée avec succès!`);
    
    setShowNuclearModal(false);
    setNuclearAction(null);
  };
  
  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="flex">
        <AdminSidebar />
        
        <div className="flex-1">
          {/* Header */}
          <div className="bg-gray-800 border-b border-gray-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white">Tableau de Bord Dieu</h1>
                <p className="text-gray-400">Contrôle absolu sur Pay Fusion</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm text-gray-400">Connecté en tant que</div>
                  <div className="font-medium text-white">{user.email}</div>
                </div>
                
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8941F] flex items-center justify-center text-white font-bold text-xl">
                  {user.email?.charAt(0).toUpperCase()}
                </div>
              </div>
            </div>
          </div>
          
          <main className="p-6">
            {/* Statistiques */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card variant="secondary" className="bg-gray-800 border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-bold text-white mb-1">{stats.totalUsers}</div>
                    <div className="text-gray-400">Utilisateurs totaux</div>
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg">
                    <Icon name="users" size="24px" color="#9CA3AF" />
                  </div>
                </div>
              </Card>
              
              <Card variant="secondary" className="bg-gray-800 border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-bold text-white mb-1">{stats.activeUsers}</div>
                    <div className="text-gray-400">Utilisateurs actifs</div>
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg">
                    <Icon name="activity" size="24px" color="#10B981" />
                  </div>
                </div>
              </Card>
              
              <Card variant="secondary" className="bg-gray-800 border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-bold text-white mb-1">${stats.dailyVolume.toLocaleString()}</div>
                    <div className="text-gray-400">Volume 24h</div>
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg">
                    <Icon name="graph-up" size="24px" color="#3B82F6" />
                  </div>
                </div>
              </Card>
              
              <Card variant="secondary" className="bg-gray-800 border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-bold text-white mb-1">{stats.systemHealth}%</div>
                    <div className="text-gray-400">Santé système</div>
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg">
                    <Icon name="heart" size="24px" color="#EF4444" />
                  </div>
                </div>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* Alertes */}
              <div className="lg:col-span-2">
                <Card 
                  title="Alertes Système" 
                  icon="alert"
                  className="bg-gray-800 border-gray-700"
                >
                  <div className="space-y-3">
                    {alerts.map(alert => (
                      <div 
                        key={alert.id}
                        className={`p-4 rounded-lg border ${getPriorityColor(alert.priority)} flex items-center gap-3`}
                      >
                        <Icon 
                          name={alert.type === 'danger' ? 'exclamation-triangle' : 
                                alert.type === 'warning' ? 'exclamation-circle' : 'info-circle'} 
                          size="20px"
                        />
                        <div className="flex-1">
                          <div className="font-medium">{alert.message}</div>
                        </div>
                        <Button
                          size="small"
                          variant="ghost"
                          onClick={() => router.push('/god/' + (alert.type === 'warning' ? 'kyc' : 'transactions'))}
                        >
                          Voir →
                        </Button>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
              
              {/* Actions rapides */}
              <div>
                <Card 
                  title="Actions Rapides" 
                  icon="bolt"
                  className="bg-gray-800 border-gray-700"
                >
                  <div className="space-y-3">
                    <Button
                      variant="primary"
                      icon="users"
                      className="w-full"
                      onClick={() => router.push('/god/users')}
                    >
                      Gérer Utilisateurs
                    </Button>
                    
                    <Button
                      variant="secondary"
                      icon="transactions"
                      className="w-full"
                      onClick={() => router.push('/god/transactions')}
                    >
                      Valider Transactions
                    </Button>
                    
                    <Button
                      variant="secondary"
                      icon="edit"
                      className="w-full"
                      onClick={() => router.push('/god/editor')}
                    >
                      Éditeur Site
                    </Button>
                    
                    <Button
                      variant="secondary"
                      icon="database"
                      className="w-full"
                      onClick={() => router.push('/god/database')}
                    >
                      Base de Données
                    </Button>
                  </div>
                </Card>
              </div>
            </div>
            
            {/* Activité récente */}
            <div className="mb-8">
              <Card 
                title="Activité Récente" 
                icon="history"
                className="bg-gray-800 border-gray-700"
              >
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Utilisateur</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Action</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Détails</th>
                        <th className="py-3 px-4 text-left text-sm font-medium text-gray-400">Heure</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentActivity.map(activity => (
                        <tr key={activity.id} className="border-b border-gray-700 hover:bg-gray-750">
                          <td className="py-3 px-4">
                            <div className="font-medium text-white">{activity.user}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-gray-300">{activity.action}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-sm text-gray-400">
                              {activity.amount || activity.userAffected || activity.type || activity.ip || '-'}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-sm text-gray-400">{activity.time}</div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
            
            {/* Actions Nucléaires */}
            <div>
              <Card 
                title="Fonctions Nucléaires" 
                icon="nuclear"
                className="bg-gray-800 border-gray-700 border-2 border-red-500/30"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {nuclearActions.map(action => (
                    <button
                      key={action.id}
                      onClick={() => handleNuclearAction(action)}
                      className={`
                        p-4 rounded-lg border text-left transition-all
                        hover:scale-[1.02] hover:shadow-lg
                        ${action.bg} ${action.color} border-current/20
                      `}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <Icon name={action.icon} size="24px" />
                        <div className="font-bold">{action.title}</div>
                      </div>
                      <p className="text-sm opacity-80">{action.description}</p>
                      <div className="mt-3 text-xs font-medium">
                        {action.level === 'danger' ? '⚠️ Danger élevé' : 
                         action.level === 'warning' ? '⚠️ Attention requise' : 'ℹ️ Information'}
                      </div>
                    </button>
                  ))}
                </div>
                
                <div className="mt-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
                  <div className="flex items-start gap-3">
                    <Icon name="warning" size="24px" color="#F87171" />
                    <div>
                      <h4 className="font-bold text-red-400 mb-1">Avertissement</h4>
                      <p className="text-sm text-gray-400">
                        Ces actions ont un impact direct sur le système et les utilisateurs.
                        Utilisez-les avec extrême prudence. Toutes les actions sont journalisées.
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </main>
        </div>
      </div>
      
      {/* Modal d'action nucléaire */}
      <Modal
        isOpen={showNuclearModal}
        onClose={() => {
          setShowNuclearModal(false);
          setNuclearAction(null);
        }}
        title={nuclearAction?.title}
        className="bg-gray-800 border-gray-700"
      >
        {nuclearAction && (
          <div className="space-y-4">
            <div className={`p-4 rounded-lg ${nuclearAction.bg} ${nuclearAction.color} border-current/20`}>
              <div className="flex items-center gap-3">
                <Icon name={nuclearAction.icon} size="32px" />
                <div>
                  <h4 className="font-bold text-lg">Attention !</h4>
                  <p>{nuclearAction.description}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
              <h4 className="font-medium text-white mb-3">Conséquences:</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <Icon name="check" size="16px" className="text-red-400 mt-0.5" />
                  <span>Impact immédiat sur tous les utilisateurs</span>
                </li>
                <li className="flex items-start gap-2">
                  <Icon name="check" size="16px" className="text-red-400 mt-0.5" />
                  <span>Action irréversible dans certains cas</span>
                </li>
                <li className="flex items-start gap-2">
                  <Icon name="check" size="16px" className="text-red-400 mt-0.5" />
                  <span>Journalisé dans les logs admin</span>
                </li>
                <li className="flex items-start gap-2">
                  <Icon name="check" size="16px" className="text-red-400 mt-0.5" />
                  <span>Nécessite confirmation multiple</span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-gray-900 rounded border border-gray-700">
                <input type="checkbox" id="confirm1" className="w-5 h-5" />
                <label htmlFor="confirm1" className="text-sm text-gray-300">
                  Je comprends les conséquences de cette action
                </label>
              </div>
              
              {nuclearAction.level === 'danger' && (
                <div className="flex items-center gap-3 p-3 bg-gray-900 rounded border border-gray-700">
                  <input type="checkbox" id="confirm2" className="w-5 h-5" />
                  <label htmlFor="confirm2" className="text-sm text-gray-300">
                    J'ai vérifié qu'aucun utilisateur n'est impacté
                  </label>
                </div>
              )}
              
              <div className="flex items-center gap-3 p-3 bg-gray-900 rounded border border-gray-700">
                <input type="checkbox" id="confirm3" className="w-5 h-5" />
                <label htmlFor="confirm3" className="text-sm text-gray-300">
                  J'accepte la responsabilité de cette action
                </label>
              </div>
            </div>
            
            <div className="flex gap-3 pt-4">
              <Button
                variant="ghost"
                onClick={() => {
                  setShowNuclearModal(false);
                  setNuclearAction(null);
                }}
                className="flex-1"
              >
                Annuler
              </Button>
              
              <Button
                variant={nuclearAction.level === 'danger' ? 'danger' : 'warning'}
                onClick={executeNuclearAction}
                className="flex-1"
              >
                Exécuter
              </Button>
            </div>
          </div>
        )}
      </Modal>
      
      {/* Tools Super Admin */}
      <GodTools />
    </div>
  );
};

export default GodDashboard;