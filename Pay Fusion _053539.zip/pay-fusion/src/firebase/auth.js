import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updatePassword,
  onAuthStateChanged
} from 'firebase/auth';
import { auth } from './config';

// Créer un utilisateur
export async function registerUser(email, password, userData) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Connexion utilisateur
export async function loginUser(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Connexion Super Admin
export async function loginSuperAdmin() {
  // Email et mot de passe fixes pour le Super Admin
  const SUPER_ADMIN_EMAIL = "payfusion@admin.com";
  const SUPER_ADMIN_PASSWORD = "PayF!PassW2025";
  
  return await loginUser(SUPER_ADMIN_EMAIL, SUPER_ADMIN_PASSWORD);
}

// Déconnexion
export async function logoutUser() {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Réinitialisation mot de passe
export async function resetPassword(email) {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Vérifier si c'est le Super Admin
export function isSuperAdmin(user) {
  return user?.email === "payfusion@admin.com";
}