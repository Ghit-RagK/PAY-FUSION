import { db } from './config';
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp
} from 'firebase/firestore';

// ==================== COLLECTIONS ====================
const COLLECTIONS = {
  USERS: 'users',
  TRANSACTIONS: 'transactions',
  CRYPTO_WALLETS: 'crypto_wallets',
  KYC_DOCUMENTS: 'kyc_documents',
  ADMIN_LOGS: 'admin_logs',
  SETTINGS: 'settings',
  SUPPORT_TICKETS: 'support_tickets'
};

// ==================== UTILISATEURS ====================
export async function getUser(userId) {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      return { success: true, data: { id: userSnap.id, ...userSnap.data() } };
    } else {
      return { success: false, error: 'Utilisateur non trouvé' };
    }
  } catch (error) {
    console.error('Error getting user:', error);
    return { success: false, error: error.message };
  }
}

export async function createUser(userId, userData) {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    
    await setDoc(userRef, {
      ...userData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      status: 'active',
      kycStatus: 'pending',
      emailVerified: false,
      phoneVerified: false,
      totalBalance: 0,
      totalDeposits: 0,
      totalWithdrawals: 0
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error creating user:', error);
    return { success: false, error: error.message };
  }
}

export async function updateUser(userId, updates) {
  try {
    const userRef = doc(db, COLLECTIONS.USERS, userId);
    
    await updateDoc(userRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating user:', error);
    return { success: false, error: error.message };
  }
}

export async function getAllUsers(filters = {}) {
  try {
    let q = collection(db, COLLECTIONS.USERS);
    
    // Appliquer les filtres
    if (filters.status) {
      q = query(q, where('status', '==', filters.status));
    }
    
    if (filters.kycStatus) {
      q = query(q, where('kycStatus', '==', filters.kycStatus));
    }
    
    // Trier par date de création
    q = query(q, orderBy('createdAt', 'desc'));
    
    const querySnapshot = await getDocs(q);
    const users = [];
    
    querySnapshot.forEach((doc) => {
      users.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, data: users };
  } catch (error) {
    console.error('Error getting users:', error);
    return { success: false, error: error.message };
  }
}

// ==================== TRANSACTIONS ====================
export async function createTransaction(transactionData) {
  try {
    const transactionRef = doc(collection(db, COLLECTIONS.TRANSACTIONS));
    
    await setDoc(transactionRef, {
      ...transactionData,
      id: transactionRef.id,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      status: 'pending'
    });
    
    return { success: true, transactionId: transactionRef.id };
  } catch (error) {
    console.error('Error creating transaction:', error);
    return { success: false, error: error.message };
  }
}

export async function getUserTransactions(userId, filters = {}) {
  try {
    let q = query(
      collection(db, COLLECTIONS.TRANSACTIONS),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    if (filters.type) {
      q = query(q, where('type', '==', filters.type));
    }
    
    if (filters.status) {
      q = query(q, where('status', '==', filters.status));
    }
    
    if (filters.limit) {
      q = query(q, limit(filters.limit));
    }
    
    const querySnapshot = await getDocs(q);
    const transactions = [];
    
    querySnapshot.forEach((doc) => {
      transactions.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, data: transactions };
  } catch (error) {
    console.error('Error getting user transactions:', error);
    return { success: false, error: error.message };
  }
}

export async function getAllTransactions(filters = {}) {
  try {
    let q = query(collection(db, COLLECTIONS.TRANSACTIONS), orderBy('createdAt', 'desc'));
    
    if (filters.status) {
      q = query(q, where('status', '==', filters.status));
    }
    
    if (filters.type) {
      q = query(q, where('type', '==', filters.type));
    }
    
    if (filters.limit) {
      q = query(q, limit(filters.limit));
    }
    
    const querySnapshot = await getDocs(q);
    const transactions = [];
    
    querySnapshot.forEach((doc) => {
      transactions.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, data: transactions };
  } catch (error) {
    console.error('Error getting all transactions:', error);
    return { success: false, error: error.message };
  }
}

// ==================== PORTEFEUILLES CRYPTO ====================
export async function getUserCryptoWallets(userId) {
  try {
    const q = query(
      collection(db, COLLECTIONS.CRYPTO_WALLETS),
      where('userId', '==', userId)
    );
    
    const querySnapshot = await getDocs(q);
    const wallets = {};
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      wallets[data.symbol] = data;
    });
    
    return { success: true, data: wallets };
  } catch (error) {
    console.error('Error getting user crypto wallets:', error);
    return { success: false, error: error.message };
  }
}

export async function updateCryptoWallet(userId, symbol, updates) {
  try {
    const walletId = `${userId}_${symbol}`;
    const walletRef = doc(db, COLLECTIONS.CRYPTO_WALLETS, walletId);
    
    await setDoc(walletRef, {
      userId,
      symbol,
      ...updates,
      updatedAt: serverTimestamp()
    }, { merge: true });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating crypto wallet:', error);
    return { success: false, error: error.message };
  }
}

// ==================== KYC DOCUMENTS ====================
export async function uploadKycDocument(userId, documentData) {
  try {
    const kycId = `${userId}_${Date.now()}`;
    const kycRef = doc(db, COLLECTIONS.KYC_DOCUMENTS, kycId);
    
    await setDoc(kycRef, {
      userId,
      ...documentData,
      status: 'pending',
      submittedAt: serverTimestamp(),
      reviewedAt: null,
      reviewerId: null
    });
    
    // Mettre à jour le statut KYC de l'utilisateur
    await updateUser(userId, { kycStatus: 'pending' });
    
    return { success: true, kycId };
  } catch (error) {
    console.error('Error uploading KYC document:', error);
    return { success: false, error: error.message };
  }
}

export async function getPendingKycDocuments() {
  try {
    const q = query(
      collection(db, COLLECTIONS.KYC_DOCUMENTS),
      where('status', '==', 'pending'),
      orderBy('submittedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const documents = [];
    
    querySnapshot.forEach((doc) => {
      documents.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, data: documents };
  } catch (error) {
    console.error('Error getting pending KYC documents:', error);
    return { success: false, error: error.message };
  }
}

export async function updateKycStatus(kycId, status, reviewerId, notes = '') {
  try {
    const kycRef = doc(db, COLLECTIONS.KYC_DOCUMENTS, kycId);
    const kycSnap = await getDoc(kycRef);
    
    if (!kycSnap.exists()) {
      return { success: false, error: 'Document KYC non trouvé' };
    }
    
    const kycData = kycSnap.data();
    
    await updateDoc(kycRef, {
      status,
      reviewerId,
      reviewedAt: serverTimestamp(),
      notes
    });
    
    // Mettre à jour le statut KYC de l'utilisateur
    await updateUser(kycData.userId, { kycStatus: status });
    
    // Log de l'action admin
    await logAdminAction(reviewerId, 'kyc_review', {
      kycId,
      userId: kycData.userId,
      oldStatus: kycData.status,
      newStatus: status,
      notes
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating KYC status:', error);
    return { success: false, error: error.message };
  }
}

// ==================== LOGS ADMIN ====================
export async function logAdminAction(adminId, action, details = {}) {
  try {
    const logRef = doc(collection(db, COLLECTIONS.ADMIN_LOGS));
    
    await setDoc(logRef, {
      adminId,
      action,
      details,
      timestamp: serverTimestamp(),
      ipAddress: details.ip || 'unknown',
      userAgent: details.userAgent || 'unknown'
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error logging admin action:', error);
    return { success: false, error: error.message };
  }
}

export async function getAdminLogs(filters = {}) {
  try {
    let q = query(collection(db, COLLECTIONS.ADMIN_LOGS), orderBy('timestamp', 'desc'));
    
    if (filters.adminId) {
      q = query(q, where('adminId', '==', filters.adminId));
    }
    
    if (filters.action) {
      q = query(q, where('action', '==', filters.action));
    }
    
    if (filters.limit) {
      q = query(q, limit(filters.limit));
    }
    
    const querySnapshot = await getDocs(q);
    const logs = [];
    
    querySnapshot.forEach((doc) => {
      logs.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, data: logs };
  } catch (error) {
    console.error('Error getting admin logs:', error);
    return { success: false, error: error.message };
  }
}

// ==================== CONFIGURATIONS ====================
export async function getSettings() {
  try {
    const settingsRef = doc(db, COLLECTIONS.SETTINGS, 'global');
    const settingsSnap = await getDoc(settingsRef);
    
    if (settingsSnap.exists()) {
      return { success: true, data: settingsSnap.data() };
    } else {
      // Créer les paramètres par défaut
      const defaultSettings = {
        siteName: 'Pay Fusion',
        primaryColor: '#D4AF37',
        secondaryColor: '#FFFFFF',
        maintenanceMode: false,
        registrationEnabled: true,
        tradingEnabled: true,
        withdrawalsEnabled: true,
        fees: {
          deposit: 0,
          withdrawal: 2.5,
          trade: 0.1,
          swap: 0.1
        },
        limits: {
          minDeposit: 5,
          maxDeposit: 10000,
          minWithdrawal: 10,
          maxWithdrawal: 5000,
          dailyWithdrawalLimit: 20000
        },
        supportedCryptos: ['BTC', 'ETH', 'BNB', 'SOL', 'TRX', 'USDT', 'MATIC', 'USD'],
        supportedCurrencies: ['USD', 'EUR', 'HTG', 'CAD', 'GBP'],
        supportedLanguages: ['fr', 'ht', 'en', 'es', 'pt', 'ar', 'zh', 'ru', 'de', 'ja'],
        updatedAt: serverTimestamp()
      };
      
      await setDoc(settingsRef, defaultSettings);
      return { success: true, data: defaultSettings };
    }
  } catch (error) {
    console.error('Error getting settings:', error);
    return { success: false, error: error.message };
  }
}

export async function updateSettings(updates) {
  try {
    const settingsRef = doc(db, COLLECTIONS.SETTINGS, 'global');
    
    await updateDoc(settingsRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating settings:', error);
    return { success: false, error: error.message };
  }
}

// ==================== STATISTIQUES ====================
export async function getPlatformStats() {
  try {
    // Récupérer le nombre total d'utilisateurs
    const usersQuery = query(collection(db, COLLECTIONS.USERS));
    const usersSnapshot = await getDocs(usersQuery);
    const totalUsers = usersSnapshot.size;
    
    // Récupérer les utilisateurs actifs (connectés dans les dernières 24h)
    const activeUsersQuery = query(
      collection(db, COLLECTIONS.USERS),
      where('lastLogin', '>=', new Date(Date.now() - 24 * 60 * 60 * 1000))
    );
    const activeUsersSnapshot = await getDocs(activeUsersQuery);
    const activeUsers = activeUsersSnapshot.size;
    
    // Récupérer les transactions du jour
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const transactionsQuery = query(
      collection(db, COLLECTIONS.TRANSACTIONS),
      where('createdAt', '>=', today)
    );
    const transactionsSnapshot = await getDocs(transactionsQuery);
    const todayTransactions = transactionsSnapshot.size;
    
    // Calculer le volume du jour
    let todayVolume = 0;
    transactionsSnapshot.forEach(doc => {
      const data = doc.data();
      if (data.amount && data.status === 'completed') {
        todayVolume += parseFloat(data.amount) || 0;
      }
    });
    
    // Récupérer les KYC en attente
    const pendingKycQuery = query(
      collection(db, COLLECTIONS.KYC_DOCUMENTS),
      where('status', '==', 'pending')
    );
    const pendingKycSnapshot = await getDocs(pendingKycQuery);
    const pendingKyc = pendingKycSnapshot.size;
    
    return {
      success: true,
      data: {
        totalUsers,
        activeUsers,
        todayTransactions,
        todayVolume,
        pendingKyc
      }
    };
  } catch (error) {
    console.error('Error getting platform stats:', error);
    return { success: false, error: error.message };
  }
}