import twilio from 'twilio';

// Configuration Twilio (À remplir avec vos infos)
const TWILIO_CONFIG = {
  accountSid: process.env.NEXT_PUBLIC_TWILIO_ACCOUNT_SID,
  authToken: process.env.NEXT_PUBLIC_TWILIO_AUTH_TOKEN,
  phoneNumber: process.env.NEXT_PUBLIC_TWILIO_PHONE_NUMBER
};

// Initialiser le client Twilio
let twilioClient = null;
if (TWILIO_CONFIG.accountSid && TWILIO_CONFIG.authToken) {
  twilioClient = twilio(TWILIO_CONFIG.accountSid, TWILIO_CONFIG.authToken);
}

// Format des numéros de téléphone
function formatPhoneNumber(phone, countryCode = 'HT') {
  // Supprimer tous les caractères non numériques
  const cleaned = phone.replace(/\D/g, '');
  
  // Ajouter le code pays si nécessaire
  if (!cleaned.startsWith('+')) {
    const countryCodes = {
      'HT': '+509',
      'FR': '+33',
      'US': '+1',
      'CA': '+1',
      'BE': '+32',
      'CH': '+41',
      'GB': '+44'
    };
    
    const code = countryCodes[countryCode] || '+1';
    return code + cleaned;
  }
  
  return cleaned;
}

// Envoyer un SMS de vérification
export async function sendVerificationSMS(phoneNumber, verificationCode, countryCode = 'HT') {
  try {
    if (!twilioClient) {
      console.warn('Twilio non configuré. Mode simulation activé.');
      console.log(`SMS de vérification pour ${phoneNumber}: Code ${verificationCode}`);
      return { success: true, simulated: true };
    }
    
    const formattedNumber = formatPhoneNumber(phoneNumber, countryCode);
    
    const message = await twilioClient.messages.create({
      body: `Votre code de vérification Pay Fusion: ${verificationCode}. Valide 10 minutes.`,
      from: TWILIO_CONFIG.phoneNumber,
      to: formattedNumber
    });
    
    console.log(`SMS envoyé avec SID: ${message.sid}`);
    return { 
      success: true, 
      messageId: message.sid,
      to: formattedNumber
    };
  } catch (error) {
    console.error('Erreur envoi SMS:', error);
    return { 
      success: false, 
      error: error.message,
      code: error.code
    };
  }
}

// Envoyer un SMS de notification de transaction
export async function sendTransactionSMS(phoneNumber, transactionData, countryCode = 'HT') {
  try {
    if (!twilioClient) {
      console.warn('Twilio non configuré. Mode simulation activé.');
      console.log(`SMS transaction pour ${phoneNumber}:`, transactionData);
      return { success: true, simulated: true };
    }
    
    const formattedNumber = formatPhoneNumber(phoneNumber, countryCode);
    
    let messageBody = '';
    switch(transactionData.type) {
      case 'deposit':
        messageBody = `Dépôt reçu: ${transactionData.amount} ${transactionData.currency}. Solde mis à jour.`;
        break;
      case 'withdrawal':
        messageBody = `Retrait approuvé: ${transactionData.amount} ${transactionData.currency}. Traitement en cours.`;
        break;
      case 'buy':
        messageBody = `Achat confirmé: ${transactionData.amount} ${transactionData.crypto} pour ${transactionData.fiatAmount} ${transactionData.currency}.`;
        break;
      case 'sell':
        messageBody = `Vente confirmée: ${transactionData.amount} ${transactionData.crypto} pour ${transactionData.fiatAmount} ${transactionData.currency}.`;
        break;
      default:
        messageBody = `Transaction ${transactionData.type}: ${transactionData.amount} ${transactionData.currency}.`;
    }
    
    const message = await twilioClient.messages.create({
      body: `Pay Fusion: ${messageBody} ID: ${transactionData.id}`,
      from: TWILIO_CONFIG.phoneNumber,
      to: formattedNumber
    });
    
    return { 
      success: true, 
      messageId: message.sid 
    };
  } catch (error) {
    console.error('Erreur envoi SMS transaction:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// Envoyer un SMS de sécurité (connexion suspecte, etc.)
export async function sendSecuritySMS(phoneNumber, alertType, countryCode = 'HT') {
  try {
    if (!twilioClient) {
      console.warn('Twilio non configuré. Mode simulation activé.');
      console.log(`SMS sécurité pour ${phoneNumber}: ${alertType}`);
      return { success: true, simulated: true };
    }
    
    const formattedNumber = formatPhoneNumber(phoneNumber, countryCode);
    
    let messageBody = '';
    switch(alertType) {
      case 'login_new_device':
        messageBody = 'Nouvelle connexion détectée sur votre compte Pay Fusion.';
        break;
      case 'login_new_location':
        messageBody = 'Connexion depuis un nouvel emplacement détectée.';
        break;
      case 'password_changed':
        messageBody = 'Votre mot de passe Pay Fusion a été modifié.';
        break;
      case '2fa_enabled':
        messageBody = 'L\'authentification à deux facteurs a été activée sur votre compte.';
        break;
      case 'suspicious_activity':
        messageBody = 'Activité suspecte détectée sur votre compte Pay Fusion.';
        break;
      default:
        messageBody = 'Alerte de sécurité sur votre compte Pay Fusion.';
    }
    
    const message = await twilioClient.messages.create({
      body: `⚠️ Sécurité Pay Fusion: ${messageBody} Si ce n\'est pas vous, contactez-nous immédiatement.`,
      from: TWILIO_CONFIG.phoneNumber,
      to: formattedNumber
    });
    
    return { 
      success: true, 
      messageId: message.sid 
    };
  } catch (error) {
    console.error('Erreur envoi SMS sécurité:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// Vérifier le statut d'un SMS
export async function checkSMSStatus(messageId) {
  try {
    if (!twilioClient) {
      return { success: true, status: 'simulated' };
    }
    
    const message = await twilioClient.messages(messageId).fetch();
    
    return {
      success: true,
      status: message.status,
      sentAt: message.dateCreated,
      to: message.to,
      from: message.from,
      body: message.body,
      errorCode: message.errorCode,
      errorMessage: message.errorMessage
    };
  } catch (error) {
    console.error('Erreur vérification statut SMS:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// Générer un code de vérification
export function generateVerificationCode(length = 6) {
  const digits = '0123456789';
  let code = '';
  
  for (let i = 0; i < length; i++) {
    code += digits.charAt(Math.floor(Math.random() * digits.length));
  }
  
  return code;
}

// Stocker le code de vérification (à implémenter avec votre base de données)
export async function storeVerificationCode(phoneNumber, code) {
  // À implémenter avec Firebase/Firestore
  // Exemple:
  // await firestore.collection('verification_codes').doc(phoneNumber).set({
  //   code,
  //   expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
  //   attempts: 0
  // });
  
  console.log(`Code ${code} stocké pour ${phoneNumber}`);
  return { success: true };
}

// Vérifier un code de vérification
export async function verifyCode(phoneNumber, code) {
  // À implémenter avec Firebase/Firestore
  // Exemple:
  // const doc = await firestore.collection('verification_codes').doc(phoneNumber).get();
  // if (!doc.exists) return false;
  // 
  // const data = doc.data();
  // if (data.expiresAt < new Date()) return false;
  // if (data.code !== code) return false;
  // 
  // // Supprimer le code après vérification réussie
  // await doc.ref.delete();
  // return true;
  
  console.log(`Vérification code ${code} pour ${phoneNumber}`);
  return true; // Simulation
}

// Export des fonctions principales
export default {
  sendVerificationSMS,
  sendTransactionSMS,
  sendSecuritySMS,
  checkSMSStatus,
  generateVerificationCode,
  storeVerificationCode,
  verifyCode,
  formatPhoneNumber
};