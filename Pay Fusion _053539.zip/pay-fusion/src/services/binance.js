import axios from 'axios';

// Configuration Binance API
const BINANCE_API = {
  baseURL: 'https://api.binance.com/api/v3',
  websocketURL: 'wss://stream.binance.com:9443/ws'
};

// Paires de trading pour nos 8 cryptos
export const CRYPTO_PAIRS = {
  BTC: 'BTCUSDT',
  ETH: 'ETHUSDT',
  BNB: 'BNBUSDT',
  SOL: 'SOLUSDT',
  TRX: 'TRXUSDT',
  USDT: 'USDTUSD',
  MATIC: 'MATICUSDT',
  USD: 'BUSDUSDT'
};

// Obtenir le prix d'une crypto
export async function getCryptoPrice(symbol) {
  try {
    const pair = CRYPTO_PAIRS[symbol];
    const response = await axios.get(`${BINANCE_API.baseURL}/ticker/price`, {
      params: { symbol: pair }
    });
    
    return {
      symbol,
      price: parseFloat(response.data.price),
      pair,
      timestamp: Date.now()
    };
  } catch (error) {
    console.error(`Error fetching ${symbol} price:`, error);
    return null;
  }
}

// Obtenir les prix de toutes les cryptos
export async function getAllCryptoPrices() {
  const cryptos = Object.keys(CRYPTO_PAIRS);
  const promises = cryptos.map(symbol => getCryptoPrice(symbol));
  const results = await Promise.all(promises);
  
  return results.filter(result => result !== null);
}

// Obtenir les données 24h
export async function get24hStats(symbol) {
  try {
    const pair = CRYPTO_PAIRS[symbol];
    const response = await axios.get(`${BINANCE_API.baseURL}/ticker/24hr`, {
      params: { symbol: pair }
    });
    
    return {
      symbol,
      priceChange: parseFloat(response.data.priceChange),
      priceChangePercent: parseFloat(response.data.priceChangePercent),
      highPrice: parseFloat(response.data.highPrice),
      lowPrice: parseFloat(response.data.lowPrice),
      volume: parseFloat(response.data.volume),
      quoteVolume: parseFloat(response.data.quoteVolume)
    };
  } catch (error) {
    console.error(`Error fetching ${symbol} 24h stats:`, error);
    return null;
  }
}

// Service WebSocket pour prix temps réel
export class CryptoWebSocket {
  constructor(symbols = Object.keys(CRYPTO_PAIRS)) {
    this.symbols = symbols;
    this.socket = null;
    this.callbacks = new Map();
    this.isConnected = false;
  }
  
  connect() {
    if (this.socket) return;
    
    const streams = this.symbols.map(sym => 
      `${CRYPTO_PAIRS[sym].toLowerCase()}@ticker`
    ).join('/');
    
    this.socket = new WebSocket(`${BINANCE_API.websocketURL}/${streams}`);
    
    this.socket.onopen = () => {
      this.isConnected = true;
      console.log('Binance WebSocket connected');
    };
    
    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleMessage(data);
    };
    
    this.socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    this.socket.onclose = () => {
      this.isConnected = false;
      console.log('WebSocket disconnected');
      // Tentative de reconnexion
      setTimeout(() => this.connect(), 5000);
    };
  }
  
  handleMessage(data) {
    const symbol = Object.keys(CRYPTO_PAIRS).find(
      key => CRYPTO_PAIRS[key] === data.s.toUpperCase()
    );
    
    if (symbol) {
      const priceData = {
        symbol,
        price: parseFloat(data.c),
        change: parseFloat(data.p),
        changePercent: parseFloat(data.P),
        high: parseFloat(data.h),
        low: parseFloat(data.l),
        volume: parseFloat(data.v),
        timestamp: Date.now()
      };
      
      // Appeler tous les callbacks enregistrés
      this.callbacks.forEach(callback => callback(priceData));
    }
  }
  
  onPriceUpdate(callback) {
    const id = Date.now();
    this.callbacks.set(id, callback);
    return () => this.callbacks.delete(id);
  }
  
  disconnect() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
  }
}