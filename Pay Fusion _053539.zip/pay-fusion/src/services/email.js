import emailjs from '@emailjs/browser';

// Configuration EmailJS (À remplir avec vos infos)
const EMAILJS_CONFIG = {
  serviceId: 'VOTRE_SERVICE_ID',
  templateId: 'VOTRE_TEMPLATE_ID',
  publicKey: 'VOTRE_PUBLIC_KEY'
};

// Initialisation
emailjs.init(EMAILJS_CONFIG.publicKey);

// Envoyer un email de vérification
export async function sendVerificationEmail(toEmail, verificationCode) {
  try {
    const templateParams = {
      to_email: toEmail,
      verification_code: verificationCode,
      app_name: 'Pay Fusion'
    };
    
    await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      EMAILJS_CONFIG.templateId,
      templateParams
    );
    
    return { success: true };
  } catch (error) {
    console.error('Email sending error:', error);
    return { success: false, error: error.message };
  }
}

// Envoyer un email de réinitialisation de mot de passe
export async function sendPasswordResetEmail(toEmail, resetLink) {
  try {
    const templateParams = {
      to_email: toEmail,
      reset_link: resetLink,
      app_name: 'Pay Fusion'
    };
    
    await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      'password_reset_template', // Template spécifique
      templateParams
    );
    
    return { success: true };
  } catch (error) {
    console.error('Password reset email error:', error);
    return { success: false, error: error.message };
  }
}

// Envoyer une notification de transaction
export async function sendTransactionNotification(toEmail, transactionData) {
  try {
    const templateParams = {
      to_email: toEmail,
      transaction_type: transactionData.type,
      amount: transactionData.amount,
      currency: transactionData.currency,
      date: new Date().toLocaleDateString(),
      app_name: 'Pay Fusion'
    };
    
    await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      'transaction_notification_template',
      templateParams
    );
    
    return { success: true };
  } catch (error) {
    console.error('Transaction notification error:', error);
    return { success: false, error: error.message };
  }
}