export const theme = {
  colors: {
    primary: '#D4AF37',
    primaryDark: '#B8941F',
    white: '#FFFFFF',
    black: '#1A1A1A',
    grayLight: '#F8F9FA',
    gray: '#6C757D',
    success: '#28a745',
    danger: '#dc3545',
    warning: '#ffc107',
    info: '#17a2b8'
  },
  fonts: {
    heading: 'Montserrat, sans-serif',
    body: 'Inter, sans-serif',
    code: 'JetBrains Mono, monospace'
  },
  breakpoints: {
    mobile: '480px',
    tablet: '768px',
    desktop: '1024px',
    wide: '1440px'
  }
}