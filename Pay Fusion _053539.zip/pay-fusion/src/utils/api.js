import axios from 'axios';

// Configuration de base pour toutes les requêtes API
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'https://api.payfusion.com',
  timeout: 30000, // 30 secondes
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

// Intercepteur pour ajouter le token d'authentification
api.interceptors.request.use(
  (config) => {
    // Récupérer le token depuis localStorage
    const token = localStorage.getItem('auth_token');
    
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Intercepteur pour gérer les erreurs
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Gérer les erreurs HTTP
    if (error.response) {
      switch (error.response.status) {
        case 401:
          // Non autorisé - déconnecter l'utilisateur
          localStorage.removeItem('auth_token');
          window.location.href = '/auth/login';
          break;
        
        case 403:
          // Accès interdit
          console.error('Accès interdit:', error.response.data);
          break;
        
        case 404:
          // Ressource non trouvée
          console.error('Ressource non trouvée:', error.response.data);
          break;
        
        case 429:
          // Trop de requêtes
          console.error('Trop de requêtes. Veuillez patienter.');
          break;
        
        case 500:
          // Erreur serveur
          console.error('Erreur serveur:', error.response.data);
          break;
        
        default:
          console.error('Erreur HTTP:', error.response.status, error.response.data);
      }
    } else if (error.request) {
      // La requête a été faite mais aucune réponse n'a été reçue
      console.error('Pas de réponse du serveur:', error.request);
    } else {
      // Quelque chose s'est mal passé lors de la configuration de la requête
      console.error('Erreur de configuration:', error.message);
    }
    
    return Promise.reject(error);
  }
);

// Fonctions API pour Pay Fusion

// ==================== AUTHENTIFICATION ====================
export const authAPI = {
  login: (email, password) => 
    api.post('/auth/login', { email, password }),
  
  register: (userData) => 
    api.post('/auth/register', userData),
  
  verifyEmail: (token) => 
    api.post('/auth/verify-email', { token }),
  
  forgotPassword: (email) => 
    api.post('/auth/forgot-password', { email }),
  
  resetPassword: (token, newPassword) => 
    api.post('/auth/reset-password', { token, newPassword }),
  
  verifyPhone: (phone, code) => 
    api.post('/auth/verify-phone', { phone, code }),
  
  resendVerification: (email) => 
    api.post('/auth/resend-verification', { email })
};

// ==================== UTILISATEURS ====================
export const usersAPI = {
  getProfile: () => 
    api.get('/users/profile'),
  
  updateProfile: (profileData) => 
    api.put('/users/profile', profileData),
  
  changePassword: (currentPassword, newPassword) => 
    api.post('/users/change-password', { currentPassword, newPassword }),
  
  enable2FA: () => 
    api.post('/users/enable-2fa'),
  
  verify2FA: (code) => 
    api.post('/users/verify-2fa', { code }),
  
  disable2FA: (code) => 
    api.post('/users/disable-2fa', { code }),
  
  getSessions: () => 
    api.get('/users/sessions'),
  
  terminateSession: (sessionId) => 
    api.delete(`/users/sessions/${sessionId}`),
  
  deleteAccount: (password) => 
    api.delete('/users/account', { data: { password } })
};

// ==================== PORTEFEUILLE ====================
export const walletAPI = {
  getBalance: () => 
    api.get('/wallet/balance'),
  
  getTransactions: (params) => 
    api.get('/wallet/transactions', { params }),
  
  getCryptoWallets: () => 
    api.get('/wallet/crypto'),
  
  deposit: (data) => 
    api.post('/wallet/deposit', data),
  
  withdraw: (data) => 
    api.post('/wallet/withdraw', data),
  
  getDepositMethods: () => 
    api.get('/wallet/deposit-methods'),
  
  getWithdrawalMethods: () => 
    api.get('/wallet/withdrawal-methods'),
  
  getExchangeRates: () => 
    api.get('/wallet/exchange-rates'),
  
  convertCurrency: (from, to, amount) => 
    api.post('/wallet/convert', { from, to, amount })
};

// ==================== TRADING ====================
export const tradingAPI = {
  getMarketData: (symbol) => 
    api.get(`/trading/market/${symbol}`),
  
  getAllMarketData: () => 
    api.get('/trading/market'),
  
  buyCrypto: (data) => 
    api.post('/trading/buy', data),
  
  sellCrypto: (data) => 
    api.post('/trading/sell', data),
  
  swapCrypto: (data) => 
    api.post('/trading/swap', data),
  
  getOrderBook: (symbol) => 
    api.get(`/trading/orderbook/${symbol}`),
  
  getTradeHistory: (symbol, limit = 50) => 
    api.get(`/trading/history/${symbol}`, { params: { limit } }),
  
  createLimitOrder: (data) => 
    api.post('/trading/limit-order', data),
  
  cancelOrder: (orderId) => 
    api.delete(`/trading/orders/${orderId}`),
  
  getOpenOrders: () => 
    api.get('/trading/open-orders'),
  
  getOrderHistory: (params) => 
    api.get('/trading/order-history', { params })
};

// ==================== KYC ====================
export const kycAPI = {
  uploadDocument: (formData) => 
    api.post('/kyc/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }),
  
  getKycStatus: () => 
    api.get('/kyc/status'),
  
  getDocumentTypes: () => 
    api.get('/kyc/document-types'),
  
  getUploadInstructions: () => 
    api.get('/kyc/instructions')
};

// ==================== SUPPORT ====================
export const supportAPI = {
  createTicket: (data) => 
    api.post('/support/tickets', data),
  
  getTickets: (params) => 
    api.get('/support/tickets', { params }),
  
  getTicket: (ticketId) => 
    api.get(`/support/tickets/${ticketId}`),
  
  addMessage: (ticketId, message) => 
    api.post(`/support/tickets/${ticketId}/messages`, { message }),
  
  closeTicket: (ticketId) => 
    api.put(`/support/tickets/${ticketId}/close`),
  
  getFAQs: () => 
    api.get('/support/faqs'),
  
  searchKnowledgeBase: (query) => 
    api.get('/support/knowledge-base', { params: { query } })
};

// ==================== ADMIN ====================
export const adminAPI = {
  // Statistiques
  getStats: () => 
    api.get('/admin/stats'),
  
  // Utilisateurs
  getUsers: (params) => 
    api.get('/admin/users', { params }),
  
  getUser: (userId) => 
    api.get(`/admin/users/${userId}`),
  
  updateUser: (userId, data) => 
    api.put(`/admin/users/${userId}`, data),
  
  banUser: (userId, reason) => 
    api.post(`/admin/users/${userId}/ban`, { reason }),
  
  unbanUser: (userId) => 
    api.post(`/admin/users/${userId}/unban`),
  
  impersonateUser: (userId) => 
    api.post(`/admin/users/${userId}/impersonate`),
  
  // Transactions
  getTransactions: (params) => 
    api.get('/admin/transactions', { params }),
  
  approveTransaction: (transactionId) => 
    api.post(`/admin/transactions/${transactionId}/approve`),
  
  rejectTransaction: (transactionId, reason) => 
    api.post(`/admin/transactions/${transactionId}/reject`, { reason }),
  
  // KYC
  getPendingKyc: () => 
    api.get('/admin/kyc/pending'),
  
  approveKyc: (kycId) => 
    api.post(`/admin/kyc/${kycId}/approve`),
  
  rejectKyc: (kycId, reason) => 
    api.post(`/admin/kyc/${kycId}/reject`, { reason }),
  
  // Système
  getSystemHealth: () => 
    api.get('/admin/system/health'),
  
  toggleMaintenance: (enabled) => 
    api.post('/admin/system/maintenance', { enabled }),
  
  clearCache: () => 
    api.post('/admin/system/clear-cache'),
  
  backupDatabase: () => 
    api.post('/admin/system/backup'),
  
  // Logs
  getLogs: (params) => 
    api.get('/admin/logs', { params }),
  
  // Paramètres
  getSettings: () => 
    api.get('/admin/settings'),
  
  updateSettings: (settings) => 
    api.put('/admin/settings', settings)
};

// ==================== PUBLIC ====================
export const publicAPI = {
  getCryptoPrices: () => 
    api.get('/public/crypto/prices'),
  
  getCryptoInfo: (symbol) => 
    api.get(`/public/crypto/${symbol}`),
  
  getExchangeRates: () => 
    api.get('/public/exchange-rates'),
  
  getAnnouncements: () => 
    api.get('/public/announcements'),
  
  getBlogPosts: () => 
    api.get('/public/blog'),
  
  contactUs: (data) => 
    api.post('/public/contact', data)
};

// Fonctions utilitaires
export const apiUtils = {
  // Formater les erreurs
  formatError: (error) => {
    if (error.response && error.response.data) {
      return error.response.data.message || 'Une erreur est survenue';
    }
    return error.message || 'Une erreur est survenue';
  },
  
  // Vérifier si c'est une erreur réseau
  isNetworkError: (error) => {
    return !error.response;
  },
  
  // Vérifier si c'est une erreur d'authentification
  isAuthError: (error) => {
    return error.response && error.response.status === 401;
  },
  
  // Vérifier si c'est une erreur de validation
  isValidationError: (error) => {
    return error.response && error.response.status === 422;
  },
  
  // Obtenir les erreurs de validation
  getValidationErrors: (error) => {
    if (error.response && error.response.status === 422 && error.response.data.errors) {
      return error.response.data.errors;
    }
    return {};
  }
};

export default api;