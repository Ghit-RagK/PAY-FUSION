// Configuration des langues
export const LANGUAGES = [
  { code: 'fr', name: 'Français', flag: 'france' },
  { code: 'ht', name: 'Kreyòl Ayisyen', flag: 'haiti' },
  { code: 'en', name: 'English', flag: 'usa' },
  { code: 'es', name: 'Español', flag: 'es' },
  { code: 'pt', name: 'Português', flag: 'pt' },
  { code: 'ar', name: 'العربية', flag: 'sa' },
  { code: 'zh', name: '中文', flag: 'cn' },
  { code: 'ru', name: 'Русский', flag: 'ru' },
  { code: 'de', name: 'Deutsch', flag: 'de' },
  { code: 'ja', name: '日本語', flag: 'jp' }
];

// Traductions de base
export const TRANSLATIONS = {
  fr: {
    dashboard: 'Tableau de bord',
    wallet: 'Portefeuille',
    market: 'Marché Crypto',
    swap: 'Swapper',
    wise: 'Recharge Wise',
    history: 'Historique',
    settings: 'Paramètres',
    support: 'Support',
    logout: 'Déconnexion'
  },
  ht: {
    dashboard: 'Tablo Kontwòl',
    wallet: 'Bous',
    market: 'Mache Crypto',
    swap: 'Echanj',
    wise: 'Rechaj Wise',
    history: 'Istorik',
    settings: 'Paramèt',
    support: 'Sipò',
    logout: 'Dekoneksyon'
  },
  en: {
    dashboard: 'Dashboard',
    wallet: 'Wallet',
    market: 'Crypto Market',
    swap: 'Swapper',
    wise: 'Wise Recharge',
    history: 'History',
    settings: 'Settings',
    support: 'Support',
    logout: 'Logout'
  }
};

// Fonction pour obtenir la traduction
export function getTranslation(key, language = 'fr') {
  return TRANSLATIONS[language]?.[key] || key;
}