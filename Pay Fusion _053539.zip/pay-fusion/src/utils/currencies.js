// Configuration des devises
export const CURRENCIES = {
  USD: { symbol: '$', name: 'Dollar US', code: 'USD' },
  EUR: { symbol: '€', name: 'Euro', code: 'EUR' },
  HTG: { symbol: 'G', name: 'Gourde Haïtienne', code: 'HTG' },
  CAD: { symbol: '$', name: 'Dollar Canadien', code: 'CAD' },
  GBP: { symbol: '£', name: 'Livre Sterling', code: 'GBP' }
};

// Taux de change de référence (mise à jour via API)
export const EXCHANGE_RATES = {
  USD: 1,
  EUR: 0.85,
  HTG: 132.5,
  CAD: 1.35,
  GBP: 0.73
};

// Fonction de conversion
export function convertCurrency(amount, fromCurrency, toCurrency) {
  const amountInUSD = amount / EXCHANGE_RATES[fromCurrency];
  return amountInUSD * EXCHANGE_RATES[toCurrency];
}

// Format monétaire
export function formatCurrency(amount, currencyCode = 'USD') {
  const currency = CURRENCIES[currencyCode];
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  
  return formatter.format(amount);
}