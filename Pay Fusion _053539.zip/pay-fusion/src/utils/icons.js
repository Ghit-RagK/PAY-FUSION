// Configuration des icônes
export const ICON_SOURCES = {
  bootstrap: 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/icons',
  cryptologos: 'https://cryptologos.cc/logos',
  flagcdn: 'https://flagcdn.com'
};

// Mapping complet des icônes
export const ICON_MAPPING = {
  // Navigation
  dashboard: `${ICON_SOURCES.bootstrap}/bar-chart.svg`,
  wallet: `${ICON_SOURCES.bootstrap}/wallet2.svg`,
  market: `${ICON_SOURCES.bootstrap}/graph-up.svg`,
  swap: `${ICON_SOURCES.bootstrap}/arrow-left-right.svg`,
  wise: `${ICON_SOURCES.bootstrap}/bank2.svg`,
  history: `${ICON_SOURCES.bootstrap}/clock-history.svg`,
  settings: `${ICON_SOURCES.bootstrap}/gear.svg`,
  support: `${ICON_SOURCES.bootstrap}/headset.svg`,
  logout: `${ICON_SOURCES.bootstrap}/box-arrow-right.svg`,
  menu: `${ICON_SOURCES.bootstrap}/layout-sidebar.svg`,
  
  // Actions
  buy: `${ICON_SOURCES.bootstrap}/cart-plus.svg`,
  sell: `${ICON_SOURCES.bootstrap}/cart-dash.svg`,
  send: `${ICON_SOURCES.bootstrap}/send.svg`,
  receive: `${ICON_SOURCES.bootstrap}/inbox.svg`,
  exchange: `${ICON_SOURCES.bootstrap}/arrow-repeat.svg`,
  unlocked: `${ICON_SOURCES.bootstrap}/unlock.svg`,
  verified: `${ICON_SOURCES.bootstrap}/patch-check.svg`,
  
  // Notifications
  notification: `${ICON_SOURCES.bootstrap}/bell.svg`,
  bell: `${ICON_SOURCES.bootstrap}/bell-fill.svg`,
  email: `${ICON_SOURCES.bootstrap}/envelope.svg`,
  phone: `${ICON_SOURCES.bootstrap}/telephone.svg`,
  
  // Admin
  crown: `${ICON_SOURCES.bootstrap}/gem.svg`,
  adminDashboard: `${ICON_SOURCES.bootstrap}/speedometer2.svg`,
  users: `${ICON_SOURCES.bootstrap}/people.svg`,
  transactions: `${ICON_SOURCES.bootstrap}/cash-stack.svg`,
  
  // Langues
  haiti: `${ICON_SOURCES.flagcdn}/ht.svg`,
  france: `${ICON_SOURCES.flagcdn}/fr.svg`,
  usa: `${ICON_SOURCES.flagcdn}/us.svg`,
  canada: `${ICON_SOURCES.flagcdn}/ca.svg`,
  globe: `${ICON_SOURCES.bootstrap}/globe-americas.svg`,
  
  // Paiements
  creditCard: `${ICON_SOURCES.bootstrap}/credit-card.svg`,
  bank: `${ICON_SOURCES.bootstrap}/bank.svg`,
  qrCode: `${ICON_SOURCES.bootstrap}/qr-code.svg`,
  
  // Autres
  search: `${ICON_SOURCES.bootstrap}/search.svg`,
  close: `${ICON_SOURCES.bootstrap}/x.svg`,
  plus: `${ICON_SOURCES.bootstrap}/plus.svg`,
  minus: `${ICON_SOURCES.bootstrap}/dash.svg`,
  filter: `${ICON_SOURCES.bootstrap}/funnel.svg`,
  download: `${ICON_SOURCES.bootstrap}/download.svg`,
  upload: `${ICON_SOURCES.bootstrap}/upload.svg`,
  info: `${ICON_SOURCES.bootstrap}/info-circle.svg`,
  success: `${ICON_SOURCES.bootstrap}/check-circle.svg`,
  error: `${ICON_SOURCES.bootstrap}/x-circle.svg`,
  warning: `${ICON_SOURCES.bootstrap}/exclamation-triangle.svg`,
  edit: `${ICON_SOURCES.bootstrap}/pencil.svg`,
  delete: `${ICON_SOURCES.bootstrap}/trash.svg`,
  copy: `${ICON_SOURCES.bootstrap}/clipboard.svg`,
  share: `${ICON_SOURCES.bootstrap}/share.svg`,
  
  // Cryptos
  btc: `${ICON_SOURCES.cryptologos}/bitcoin-btc-logo.svg`,
  eth: `${ICON_SOURCES.cryptologos}/ethereum-eth-logo.svg`,
  bnb: `${ICON_SOURCES.cryptologos}/bnb-bnb-logo.svg`,
  sol: `${ICON_SOURCES.cryptologos}/solana-sol-logo.svg`,
  trx: `${ICON_SOURCES.cryptologos}/tron-trx-logo.svg`,
  usdt: `${ICON_SOURCES.cryptologos}/tether-usdt-logo.svg`,
  matic: `${ICON_SOURCES.cryptologos}/polygon-matic-logo.svg`,
  usd: `${ICON_SOURCES.cryptologos}/usd-coin-usdc-logo.svg`
};

// Fonction pour obtenir une icône
export function getIcon(iconName, size = '24px', color = 'currentColor') {
  const url = ICON_MAPPING[iconName];
  if (!url) {
    console.warn(`Icon not found: ${iconName}`);
    return null;
  }
  
  return {
    url,
    size,
    color,
    alt: `${iconName} icon`
  };
}