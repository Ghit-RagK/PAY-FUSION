import React from 'react';
import Icon from '../common/Icon';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const links = {
    Produit: [
      { label: 'Acheter Crypto', href: '/buy' },
      { label: 'Vendre Crypto', href: '/sell' },
      { label: 'Échanger', href: '/swap' },
      { label: 'Portefeuille', href: '/wallet' }
    ],
    Entreprise: [
      { label: 'À propos', href: '/about' },
      { label: 'Carrières', href: '/careers' },
      { label: 'Presse', href: '/press' },
      { label: 'Blog', href: '/blog' }
    ],
    Support: [
      { label: 'Centre d\'aide', href: '/help' },
      { label: 'Nous contacter', href: '/contact' },
      { label: 'FAQ', href: '/faq' },
      { label: 'Sécurité', href: '/security' }
    ],
    Légal: [
      { label: 'Conditions d\'utilisation', href: '/terms' },
      { label: 'Politique de confidentialité', href: '/privacy' },
      { label: 'AML/KYC', href: '/aml-kyc' },
      { label: 'Mentions légales', href: '/legal' }
    ]
  };

  return (
    <footer className="bg-[#1A1A1A] text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Logo et description */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <img src="/logo.png" alt="Pay Fusion" className="h-10 w-auto" />
              <span className="text-2xl font-bold">Pay Fusion</span>
            </div>
            
            <p className="text-gray-400 mb-6">
              Plateforme de trading crypto sécurisée avec support multilingue 
              et multi-devises. Fusionnez vos paiements, maîtrisez vos cryptos.
            </p>
            
            <div className="flex items-center gap-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Icon name="facebook" size="24px" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Icon name="twitter" size="24px" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Icon name="linkedin" size="24px" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Icon name="instagram" size="24px" />
              </a>
            </div>
          </div>
          
          {/* Liens */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h3 className="text-lg font-semibold mb-4">{category}</h3>
              <ul className="space-y-2">
                {items.map((item) => (
                  <li key={item.label}>
                    <a 
                      href={item.href}
                      className="text-gray-400 hover:text-white transition-colors"
                    >
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        {/* Divider */}
        <div className="border-t border-gray-800 my-8"></div>
        
        {/* Bottom section */}
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            © {currentYear} Pay Fusion. Tous droits réservés.
          </div>
          
          <div className="flex items-center gap-6">
            <span className="text-gray-400 text-sm">
              <Icon name="shield" size="16px" className="inline mr-1" />
              Sécurisé avec 2FA
            </span>
            
            <span className="text-gray-400 text-sm">
              <Icon name="globe" size="16px" className="inline mr-1" />
              10 langues disponibles
            </span>
            
            <span className="text-gray-400 text-sm">
              <Icon name="currency" size="16px" className="inline mr-1" />
              5 devises supportées
            </span>
          </div>
        </div>
        
        {/* Contact info */}
        <div className="mt-8 text-center text-gray-400 text-sm">
          <p>contact@payfusion.com | Support 24/7</p>
          <p className="mt-1">Pay Fusion - Plateforme de trading crypto sécurisée</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;