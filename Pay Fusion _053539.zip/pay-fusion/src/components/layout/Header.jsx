import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../common/Icon';
import Button from '../common/Button';

const Header = () => {
  const router = useRouter();
  const { user, isGod } = useAuth();
  const [language, setLanguage] = useState('fr');
  const [currency, setCurrency] = useState('USD');
  
  const languages = [
    { code: 'fr', name: 'Français', flag: 'france' },
    { code: 'ht', name: 'Kreyòl', flag: 'haiti' },
    { code: 'en', name: 'English', flag: 'usa' }
  ];
  
  const currencies = [
    { code: 'USD', symbol: '$', name: 'USD' },
    { code: 'EUR', symbol: '€', name: 'EUR' },
    { code: 'HTG', symbol: 'G', name: 'HTG' },
    { code: 'CAD', symbol: '$', name: 'CAD' },
    { code: 'GBP', symbol: '£', name: 'GBP' }
  ];

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Left side */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Pay Fusion" className="h-8 w-auto" />
              <span className="text-xl font-bold text-[#1A1A1A] hidden md:inline">
                Pay Fusion
              </span>
            </div>
            
            {/* Quick Actions */}
            <div className="hidden md:flex items-center gap-2">
              <Button
                variant="primary"
                size="small"
                icon="plus"
                onClick={() => router.push('/buy')}
              >
                Acheter
              </Button>
              
              <Button
                variant="secondary"
                size="small"
                icon="exchange"
                onClick={() => router.push('/swap')}
              >
                Échanger
              </Button>
              
              <Button
                variant="ghost"
                size="small"
                icon="send"
                onClick={() => router.push('/send')}
              >
                Envoyer
              </Button>
            </div>
          </div>
          
          {/* Right side */}
          <div className="flex items-center gap-4">
            {/* Langue et devise */}
            <div className="hidden md:flex items-center gap-3">
              <div className="relative group">
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100">
                  <Icon name={language === 'fr' ? 'france' : language === 'ht' ? 'haiti' : 'usa'} size="20px" />
                  <span className="text-sm font-medium">
                    {languages.find(l => l.code === language)?.name}
                  </span>
                  <Icon name="arrow-down" size="12px" />
                </button>
                
                <div className="absolute top-full right-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 hidden group-hover:block z-10">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setLanguage(lang.code)}
                      className="w-full flex items-center gap-3 px-4 py-2 text-left hover:bg-gray-50"
                    >
                      <Icon name={lang.flag} size="20px" />
                      <span>{lang.name}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="relative group">
                <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100">
                  <span className="text-sm font-medium">
                    {currencies.find(c => c.code === currency)?.symbol} {currency}
                  </span>
                  <Icon name="arrow-down" size="12px" />
                </button>
                
                <div className="absolute top-full right-0 mt-1 w-32 bg-white rounded-lg shadow-lg border border-gray-200 py-2 hidden group-hover:block z-10">
                  {currencies.map((curr) => (
                    <button
                      key={curr.code}
                      onClick={() => setCurrency(curr.code)}
                      className="w-full flex items-center justify-between px-4 py-2 text-left hover:bg-gray-50"
                    >
                      <span>{curr.name}</span>
                      <span>{curr.symbol}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Notifications */}
            <button className="relative p-2 hover:bg-gray-100 rounded-lg">
              <Icon name="notification" size="20px" />
              <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></div>
            </button>
            
            {/* Badge Super Admin */}
            {isGod && (
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-white rounded-full">
                <Icon name="crown" size="16px" />
                <span className="text-sm font-semibold">Super Admin</span>
              </div>
            )}
            
            {/* Profil utilisateur */}
            <div className="flex items-center gap-3">
              <div className="hidden md:block text-right">
                <div className="text-sm font-medium text-gray-900">
                  Bonjour, {user?.email?.split('@')[0] || 'Utilisateur'}
                </div>
                <div className="text-xs text-gray-500">
                  {user?.email || ''}
                </div>
              </div>
              
              <div className="w-10 h-10 rounded-full bg-[#D4AF37] flex items-center justify-center text-white font-semibold">
                {user?.email?.charAt(0).toUpperCase() || 'U'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;