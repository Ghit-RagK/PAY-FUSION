import React from 'react';
import { useRouter } from 'next/router';
import { isSuperAdmin } from '../../firebase/auth';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../common/Icon';
import { getTranslation } from '../../utils/languages';

const Sidebar = () => {
  const router = useRouter();
  const { user, logout } = useAuth();
  const isGod = isSuperAdmin(user);
  const currentLanguage = 'fr'; // À connecter avec le contexte de langue
  
  // Menu principal pour tous les utilisateurs
  const mainMenu = [
    { id: 'dashboard', icon: 'dashboard', path: '/dashboard' },
    { id: 'wallet', icon: 'wallet', path: '/wallet' },
    { id: 'market', icon: 'market', path: '/market' },
    { id: 'swap', icon: 'swap', path: '/swap' },
    { id: 'wise', icon: 'wise', path: '/wise' },
    { id: 'history', icon: 'history', path: '/history' },
    { id: 'settings', icon: 'settings', path: '/settings' },
    { id: 'support', icon: 'support', path: '/support' }
  ];
  
  // Menu Dieu (visible seulement pour payfusion@admin.com)
  const godMenu = isGod ? [
    { separator: true, label: 'ADMINISTRATION DIEU' },
    { id: 'god-dashboard', icon: 'crown', path: '/god/dashboard', glow: true },
    { id: 'god-users', icon: 'users', path: '/god/users' },
    { id: 'god-transactions', icon: 'transactions', path: '/god/transactions' },
    { id: 'god-editor', icon: 'edit', path: '/god/editor' },
    { id: 'god-database', icon: 'database', path: '/god/database' },
    { id: 'god-monitor', icon: 'monitor', path: '/god/monitor' }
  ] : [];
  
  const allMenuItems = [...mainMenu, ...godMenu];
  
  const handleNavigation = (path) => {
    router.push(path);
  };
  
  return (
    <aside className="sidebar bg-white w-64 min-h-screen border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-center">
          <img 
            src="/logo.png" 
            alt="Pay Fusion" 
            className="h-10 w-auto"
          />
        </div>
      </div>
      
      {/* Menu de navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {allMenuItems.map((item) => {
          if (item.separator) {
            return (
              <div key={item.label} className="pt-4 pb-2 px-3">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  {item.label}
                </div>
              </div>
            );
          }
          
          const isActive = router.pathname.startsWith(item.path);
          
          return (
            <button
              key={item.id}
              onClick={() => handleNavigation(item.path)}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-lg
                transition-all duration-200
                ${isActive 
                  ? 'bg-[#D4AF37] text-white shadow-gold' 
                  : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                }
                ${item.glow ? 'relative overflow-hidden' : ''}
              `}
            >
              {item.glow && (
                <div className="absolute inset-0 bg-gradient-to-r from-[#D4AF37]/20 to-transparent animate-pulse"></div>
              )}
              
              <Icon 
                name={item.icon} 
                size="20px" 
                color={isActive ? '#FFFFFF' : '#6B7280'}
              />
              
              <span className="font-medium">
                {getTranslation(item.id, currentLanguage)}
              </span>
              
              {isActive && (
                <div className="ml-auto w-2 h-2 bg-white rounded-full"></div>
              )}
            </button>
          );
        })}
      </nav>
      
      {/* Profil utilisateur et déconnexion */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3 mb-4 p-3 rounded-lg bg-gray-50">
          <div className="w-10 h-10 rounded-full bg-[#D4AF37] flex items-center justify-center text-white font-semibold">
            {user?.email?.charAt(0).toUpperCase() || 'U'}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="font-medium text-gray-900 truncate">
              {user?.email || 'Utilisateur'}
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs text-gray-500">
                {isGod ? '👑 Super Admin' : 'Utilisateur'}
              </span>
              {user?.emailVerified && (
                <Icon name="verified" size="12px" color="#10B981" />
              )}
            </div>
          </div>
        </div>
        
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-gray-900 rounded-lg transition-all duration-200"
        >
          <Icon name="logout" size="20px" color="#6B7280" />
          <span className="font-medium">
            {getTranslation('logout', currentLanguage)}
          </span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;