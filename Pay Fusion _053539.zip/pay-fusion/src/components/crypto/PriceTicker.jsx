import React, { useState, useEffect } from 'react';
import { CryptoWebSocket, getAllCryptoPrices } from '../../services/binance';
import { formatCurrency } from '../../utils/currencies';
import Icon from '../common/Icon';

const PriceTicker = ({ cryptos = ['BTC', 'ETH', 'BNB', 'SOL', 'TRX'] }) => {
  const [prices, setPrices] = useState({});
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Chargement initial
    loadInitialPrices();
    
    // Setup WebSocket pour updates en temps réel
    const ws = new CryptoWebSocket(cryptos);
    ws.connect();
    
    const unsubscribe = ws.onPriceUpdate((priceData) => {
      setPrices(prev => ({
        ...prev,
        [priceData.symbol]: priceData
      }));
    });
    
    return () => {
      unsubscribe();
      ws.disconnect();
    };
  }, [cryptos]);
  
  const loadInitialPrices = async () => {
    try {
      const initialPrices = await getAllCryptoPrices();
      const priceMap = {};
      initialPrices.forEach(price => {
        priceMap[price.symbol] = price;
      });
      setPrices(priceMap);
      setLoading(false);
    } catch (error) {
      console.error('Error loading initial prices:', error);
    }
  };
  
  const getChangeIcon = (changePercent) => {
    if (!changePercent) return null;
    return changePercent >= 0 ? 'arrow-up' : 'arrow-down';
  };
  
  const getChangeColor = (changePercent) => {
    if (!changePercent) return 'text-gray-500';
    return changePercent >= 0 ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <Icon name="market" size="18px" />
          <span className="font-semibold text-gray-900">Marché en direct</span>
        </div>
      </div>
      
      <div className="divide-y divide-gray-100">
        {cryptos.map(symbol => {
          const priceData = prices[symbol];
          
          if (loading || !priceData) {
            return (
              <div key={symbol} className="px-4 py-3 animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-20 mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-12"></div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="h-5 bg-gray-200 rounded w-24 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-16"></div>
                  </div>
                </div>
              </div>
            );
          }
          
          return (
            <div key={symbol} className="px-4 py-3 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Icon name={symbol.toLowerCase()} size="32px" />
                  
                  <div>
                    <div className="font-medium text-gray-900">
                      {symbol}
                    </div>
                    <div className="text-xs text-gray-500">
                      {getFullName(symbol)}
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-semibold text-gray-900">
                    {formatCurrency(priceData.price, 'USD')}
                  </div>
                  
                  <div className={`text-sm font-medium ${getChangeColor(priceData.changePercent)}`}>
                    <div className="flex items-center gap-1 justify-end">
                      <Icon name={getChangeIcon(priceData.changePercent)} size="12px" />
                      <span>
                        {priceData.changePercent >= 0 ? '+' : ''}
                        {priceData.changePercent?.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Helper function pour les noms complets
function getFullName(symbol) {
  const names = {
    BTC: 'Bitcoin',
    ETH: 'Ethereum',
    BNB: 'Binance Coin',
    SOL: 'Solana',
    TRX: 'Tron',
    USDT: 'Tether',
    MATIC: 'Polygon',
    USD: 'USD Coin'
  };
  return names[symbol] || symbol;
}

export default PriceTicker;