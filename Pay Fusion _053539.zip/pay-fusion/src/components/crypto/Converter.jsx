import React, { useState, useEffect } from 'react';
import { getAllCryptoPrices } from '../../services/binance';
import { convertCurrency, formatCurrency } from '../../utils/currencies';
import Icon from '../common/Icon';
import Input from '../common/Input';
import Button from '../common/Button';

const Converter = () => {
  const [cryptos, setCryptos] = useState([]);
  const [fromCrypto, setFromCrypto] = useState('BTC');
  const [toCrypto, setToCrypto] = useState('USD');
  const [amount, setAmount] = useState('1');
  const [convertedAmount, setConvertedAmount] = useState('0');
  const [exchangeRate, setExchangeRate] = useState(0);
  const [loading, setLoading] = useState(true);
  
  const allCurrencies = ['BTC', 'ETH', 'BNB', 'SOL', 'TRX', 'USDT', 'MATIC', 'USD'];
  
  useEffect(() => {
    loadCryptoPrices();
    const interval = setInterval(loadCryptoPrices, 30000); // Refresh every 30s
    
    return () => clearInterval(interval);
  }, []);
  
  useEffect(() => {
    calculateConversion();
  }, [fromCrypto, toCrypto, amount]);
  
  const loadCryptoPrices = async () => {
    try {
      const prices = await getAllCryptoPrices();
      setCryptos(prices);
      setLoading(false);
      calculateConversion(prices);
    } catch (error) {
      console.error('Error loading crypto prices:', error);
    }
  };
  
  const calculateConversion = (pricesData = cryptos) => {
    if (pricesData.length === 0 || !amount || isNaN(amount)) {
      setConvertedAmount('0');
      setExchangeRate(0);
      return;
    }
    
    const fromPrice = pricesData.find(c => c.symbol === fromCrypto)?.price;
    const toPrice = pricesData.find(c => c.symbol === toCrypto)?.price;
    
    if (!fromPrice || !toPrice) {
      setConvertedAmount('0');
      setExchangeRate(0);
      return;
    }
    
    // Calcul du taux de change
    const rate = toPrice / fromPrice;
    setExchangeRate(rate);
    
    // Calcul du montant converti
    const result = parseFloat(amount) * rate;
    setConvertedAmount(result.toFixed(6));
  };
  
  const swapCurrencies = () => {
    setFromCrypto(toCrypto);
    setToCrypto(fromCrypto);
  };
  
  const quickAmounts = [50, 100, 500, 1000];
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">
        Convertisseur Crypto
      </h3>
      
      <div className="space-y-4">
        {/* Section "De" */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-700">De</label>
            <div className="text-xs text-gray-500">
              Prix actuel: {loading ? '...' : formatCurrency(
                cryptos.find(c => c.symbol === fromCrypto)?.price || 0, 
                'USD'
              )}
            </div>
          </div>
          
          <div className="flex gap-3">
            <div className="flex-1">
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="text-2xl font-semibold"
              />
            </div>
            
            <div className="relative w-40">
              <select
                value={fromCrypto}
                onChange={(e) => setFromCrypto(e.target.value)}
                className="w-full h-full px-4 py-2.5 rounded-lg border border-gray-300 bg-white appearance-none"
              >
                {allCurrencies.map(currency => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
              
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                <Icon name="arrow-down" size="16px" />
              </div>
              
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                <Icon name={fromCrypto.toLowerCase()} size="20px" />
              </div>
            </div>
          </div>
          
          {/* Quick amounts */}
          <div className="flex gap-2 mt-3">
            {quickAmounts.map(quickAmount => (
              <button
                key={quickAmount}
                onClick={() => setAmount(quickAmount.toString())}
                className="px-3 py-1.5 text-sm bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
              >
                {quickAmount}$
              </button>
            ))}
          </div>
        </div>
        
        {/* Swap button */}
        <div className="flex justify-center">
          <button
            onClick={swapCurrencies}
            className="p-3 bg-[#D4AF37] text-white rounded-full hover:bg-[#B8941F] transition-colors"
          >
            <Icon name="exchange" size="20px" />
          </button>
        </div>
        
        {/* Section "Vers" */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-700">Vers</label>
            <div className="text-xs text-gray-500">
              Taux: 1 {fromCrypto} = {exchangeRate.toFixed(6)} {toCrypto}
            </div>
          </div>
          
          <div className="flex gap-3">
            <div className="flex-1">
              <Input
                type="text"
                value={loading ? 'Chargement...' : convertedAmount}
                readOnly
                className="text-2xl font-semibold bg-white"
              />
            </div>
            
            <div className="relative w-40">
              <select
                value={toCrypto}
                onChange={(e) => setToCrypto(e.target.value)}
                className="w-full h-full px-4 py-2.5 rounded-lg border border-gray-300 bg-white appearance-none"
              >
                {allCurrencies.map(currency => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
              
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                <Icon name="arrow-down" size="16px" />
              </div>
              
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                <Icon name={toCrypto.toLowerCase()} size="20px" />
              </div>
            </div>
          </div>
        </div>
        
        {/* Détails */}
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-100">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-gray-600">Taux de change</div>
              <div className="font-semibold">
                1 {fromCrypto} = {exchangeRate.toFixed(6)} {toCrypto}
              </div>
            </div>
            
            <div>
              <div className="text-gray-600">Frais estimés</div>
              <div className="font-semibold">0.1%</div>
            </div>
          </div>
        </div>
        
        {/* Bouton d'action */}
        <Button
          variant="primary"
          size="large"
          icon="exchange"
          className="w-full mt-4"
          onClick={() => {
            // Action de conversion
            console.log(`Convert ${amount} ${fromCrypto} to ${toCrypto}`);
          }}
        >
          Convertir maintenant
        </Button>
      </div>
    </div>
  );
};

export default Converter;