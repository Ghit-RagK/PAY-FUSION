import React, { useState, useEffect } from 'react';
import { getCryptoPrice, get24hStats } from '../../services/binance';
import { formatCurrency } from '../../utils/currencies';
import Icon from '../common/Icon';
import Button from '../common/Button';

const CryptoCard = ({ symbol, name, onBuy, onSell }) => {
  const [priceData, setPriceData] = useState(null);
  const [statsData, setStatsData] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000); // Refresh every 10s
    
    return () => clearInterval(interval);
  }, [symbol]);
  
  const loadData = async () => {
    try {
      const [price, stats] = await Promise.all([
        getCryptoPrice(symbol),
        get24hStats(symbol)
      ]);
      
      setPriceData(price);
      setStatsData(stats);
      setLoading(false);
    } catch (error) {
      console.error(`Error loading ${symbol} data:`, error);
    }
  };
  
  const getChangeColor = (changePercent) => {
    if (!changePercent) return 'text-gray-500';
    return changePercent >= 0 ? 'text-green-600' : 'text-red-600';
  };
  
  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 p-6 animate-pulse">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
            <div>
              <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-16"></div>
            </div>
          </div>
          <div className="text-right">
            <div className="h-6 bg-gray-200 rounded w-32 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-20"></div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Icon name={symbol.toLowerCase()} size="40px" />
          
          <div>
            <h3 className="font-semibold text-gray-900">{name}</h3>
            <div className="flex items-center gap-2">
              <span className="text-gray-500">{symbol}</span>
              <div className={`text-xs px-2 py-0.5 rounded-full ${
                symbol === 'USDT' || symbol === 'USD' 
                  ? 'bg-blue-100 text-blue-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {symbol === 'USDT' || symbol === 'USD' ? 'Stablecoin' : 'Volatile'}
              </div>
            </div>
          </div>
        </div>
        
        {priceData && (
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(priceData.price, 'USD')}
            </div>
            {statsData && (
              <div className={`text-sm font-medium ${getChangeColor(statsData.priceChangePercent)}`}>
                {statsData.priceChangePercent >= 0 ? '↗' : '↘'} 
                {Math.abs(statsData.priceChangePercent).toFixed(2)}%
                <span className="text-gray-500 text-xs ml-2">24h</span>
              </div>
            )}
          </div>
        )}
      </div>
      
      {statsData && (
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-xs text-gray-500 mb-1">Haut 24h</div>
            <div className="font-medium text-gray-900">
              {formatCurrency(statsData.highPrice, 'USD')}
            </div>
          </div>
          
          <div>
            <div className="text-xs text-gray-500 mb-1">Bas 24h</div>
            <div className="font-medium text-gray-900">
              {formatCurrency(statsData.lowPrice, 'USD')}
            </div>
          </div>
          
          <div>
            <div className="text-xs text-gray-500 mb-1">Volume 24h</div>
            <div className="font-medium text-gray-900">
              {formatCurrency(statsData.quoteVolume, 'USD')}
            </div>
          </div>
          
          <div>
            <div className="text-xs text-gray-500 mb-1">Variation</div>
            <div className={`font-medium ${getChangeColor(statsData.priceChangePercent)}`}>
              {statsData.priceChangePercent >= 0 ? '+' : ''}
              {formatCurrency(statsData.priceChange, 'USD')}
            </div>
          </div>
        </div>
      )}
      
      <div className="flex gap-2">
        <Button
          variant="primary"
          size="small"
          icon="buy"
          onClick={() => onBuy && onBuy(symbol)}
          className="flex-1"
        >
          Acheter
        </Button>
        
        <Button
          variant="secondary"
          size="small"
          icon="sell"
          onClick={() => onSell && onSell(symbol)}
          className="flex-1"
        >
          Vendre
        </Button>
      </div>
    </div>
  );
};

export default CryptoCard;