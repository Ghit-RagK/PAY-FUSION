import React from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../common/Icon';

const AdminSidebar = () => {
  const router = useRouter();
  const { user } = useAuth();
  
  const adminMenu = [
    {
      category: 'Surveillance',
      items: [
        { id: 'dashboard', icon: 'adminDashboard', label: 'Tableau de Bord Dieu', path: '/god/dashboard' },
        { id: 'live-monitor', icon: 'monitor', label: 'Monitoring Temps Réel', path: '/god/monitor' },
        { id: 'analytics', icon: 'graph-up', label: 'Analytiques Avancées', path: '/god/analytics' }
      ]
    },
    {
      category: 'Contrôle Utilisateurs',
      items: [
        { id: 'users', icon: 'users', label: 'Tous les Utilisateurs', path: '/god/users' },
        { id: 'kyc', icon: 'verified', label: 'Validation KYC', path: '/god/kyc' },
        { id: 'bans', icon: 'shield', label: 'Gestion des Bannissements', path: '/god/bans' },
        { id: 'impersonate', icon: 'user', label: 'Mode Impersonate', path: '/god/impersonate' }
      ]
    },
    {
      category: 'Contrôle Transactions',
      items: [
        { id: 'transactions', icon: 'transactions', label: 'Toutes Transactions', path: '/god/transactions' },
        { id: 'validation', icon: 'check-circle', label: 'Validation Transactions', path: '/god/validation' },
        { id: 'disputes', icon: 'exclamation-triangle', label: 'Litiges et Rejets', path: '/god/disputes' }
      ]
    },
    {
      category: 'Contrôle Site',
      items: [
        { id: 'editor', icon: 'edit', label: 'Éditeur Visuel', path: '/god/editor' },
        { id: 'pages', icon: 'file', label: 'Gestion Pages', path: '/god/pages' },
        { id: 'styles', icon: 'palette', label: 'Styles & Thèmes', path: '/god/styles' },
        { id: 'navigation', icon: 'menu', label: 'Navigation', path: '/god/navigation' }
      ]
    },
    {
      category: 'Système',
      items: [
        { id: 'database', icon: 'database', label: 'Base de Données', path: '/god/database' },
        { id: 'console', icon: 'terminal', label: 'Console Commande', path: '/god/console' },
        { id: 'logs', icon: 'file-list', label: 'Logs Audit', path: '/god/logs' },
        { id: 'backup', icon: 'cloud-upload', label: 'Backup & Restauration', path: '/god/backup' }
      ]
    },
    {
      category: 'Fonctions Nucléaires',
      items: [
        { id: 'maintenance', icon: 'tools', label: 'Mode Maintenance', path: '/god/maintenance', danger: true },
        { id: 'emergency', icon: 'alert', label: 'Arrêt d\'Urgence', path: '/god/emergency', danger: true },
        { id: 'reset', icon: 'refresh', label: 'Reset Partiel', path: '/god/reset', danger: true }
      ]
    }
  ];

  const handleNavigation = (path) => {
    router.push(path);
  };

  return (
    <div className="w-80 bg-gray-900 text-white min-h-screen flex flex-col">
      {/* Header Admin */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] rounded-lg">
            <Icon name="crown" size="24px" color="#FFFFFF" />
          </div>
          
          <div>
            <h1 className="text-xl font-bold">Administration Dieu</h1>
            <p className="text-sm text-gray-400">Contrôle absolu</p>
          </div>
        </div>
        
        {/* User info */}
        <div className="mt-6 p-3 bg-gray-800 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8941F] flex items-center justify-center text-white font-bold">
              {user?.email?.charAt(0).toUpperCase() || 'A'}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="font-medium truncate">{user?.email || 'Admin'}</div>
              <div className="text-xs text-gray-400 flex items-center gap-1">
                <Icon name="verified" size="12px" color="#10B981" />
                Super Admin
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Menu Navigation */}
      <div className="flex-1 overflow-y-auto py-4">
        {adminMenu.map((category, index) => (
          <div key={index} className="mb-6">
            <div className="px-6 mb-2">
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {category.category}
              </div>
            </div>
            
            <div className="space-y-1">
              {category.items.map((item) => {
                const isActive = router.pathname.startsWith(item.path);
                
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigation(item.path)}
                    className={`
                      w-full flex items-center gap-3 px-6 py-3
                      transition-all duration-200
                      ${isActive 
                        ? 'bg-gradient-to-r from-[#D4AF37]/20 to-transparent border-r-4 border-[#D4AF37]' 
                        : 'hover:bg-gray-800'
                      }
                      ${item.danger ? 'text-red-400 hover:text-red-300' : 'text-gray-300'}
                    `}
                  >
                    <Icon 
                      name={item.icon} 
                      size="18px" 
                      color={item.danger ? '#F87171' : isActive ? '#D4AF37' : '#9CA3AF'}
                    />
                    
                    <span className="font-medium">{item.label}</span>
                    
                    {isActive && (
                      <div className="ml-auto w-2 h-2 bg-[#D4AF37] rounded-full"></div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      
      {/* Footer */}
      <div className="p-4 border-t border-gray-800">
        <button
          onClick={() => router.push('/dashboard')}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors"
        >
          <Icon name="arrow-left" size="18px" />
          <span>Retour au site</span>
        </button>
        
        <div className="mt-4 text-center text-xs text-gray-500">
          <p>Mode Dieu Actif</p>
          <p className="mt-1">Toutes les actions sont journalisées</p>
        </div>
      </div>
    </div>
  );
};

export default AdminSidebar;