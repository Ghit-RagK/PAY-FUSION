import React, { useState } from 'react';
import Icon from './Icon';

const Input = ({
  label,
  type = 'text',
  value,
  onChange,
  placeholder = '',
  error = '',
  success = '',
  icon,
  required = false,
  disabled = false,
  className = '',
  ...props
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const inputType = type === 'password' && showPassword ? 'text' : type;
  
  return (
    <div className={`input-group ${className}`}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
            <Icon name={icon} size="20px" color="#6B7280" />
          </div>
        )}
        
        <input
          type={inputType}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          className={`
            w-full px-4 py-2.5 rounded-lg border
            ${icon ? 'pl-10' : 'pl-4'}
            ${type === 'password' ? 'pr-10' : 'pr-4'}
            ${error ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-[#D4AF37]'}
            ${success ? 'border-green-500 focus:border-green-500' : ''}
            ${disabled ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}
            focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/20
            transition-all duration-200
          `}
          {...props}
        />
        
        {type === 'password' && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
          >
            <Icon name={showPassword ? 'eye' : 'eye-slash'} size="20px" />
          </button>
        )}
      </div>
      
      {error && (
        <div className="flex items-center gap-1 mt-1 text-red-600 text-sm">
          <Icon name="error" size="16px" />
          <span>{error}</span>
        </div>
      )}
      
      {success && (
        <div className="flex items-center gap-1 mt-1 text-green-600 text-sm">
          <Icon name="success" size="16px" />
          <span>{success}</span>
        </div>
      )}
    </div>
  );
};

export default Input;