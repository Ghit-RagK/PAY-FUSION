import React from 'react';
import Icon from './Icon';

const Card = ({ 
  children, 
  title, 
  subtitle, 
  icon, 
  variant = 'default',
  className = '',
  ...props 
}) => {
  const variantClasses = {
    default: 'bg-white border border-gray-200',
    primary: 'bg-gradient-to-br from-[#D4AF37] to-[#B8941F] text-white',
    secondary: 'bg-gray-50 border border-gray-200',
    success: 'bg-green-50 border border-green-200',
    danger: 'bg-red-50 border border-red-200',
    warning: 'bg-yellow-50 border border-yellow-200'
  };

  return (
    <div 
      className={`
        rounded-xl shadow-sm p-6
        ${variantClasses[variant]}
        ${className}
      `}
      {...props}
    >
      {(title || icon) && (
        <div className={`mb-4 ${variant === 'primary' ? 'text-white' : 'text-gray-900'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {icon && (
                <div className={`p-2 rounded-lg ${
                  variant === 'primary' 
                    ? 'bg-white/20' 
                    : 'bg-gray-100'
                }`}>
                  <Icon 
                    name={icon} 
                    size="20px" 
                    color={variant === 'primary' ? '#FFFFFF' : '#D4AF37'}
                  />
                </div>
              )}
              
              <div>
                {title && (
                  <h3 className="text-lg font-semibold">
                    {title}
                  </h3>
                )}
                {subtitle && (
                  <p className={`text-sm ${
                    variant === 'primary' 
                      ? 'text-white/80' 
                      : 'text-gray-600'
                  }`}>
                    {subtitle}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className={variant === 'primary' ? 'text-white/90' : 'text-gray-700'}>
        {children}
      </div>
    </div>
  );
};

export default Card;