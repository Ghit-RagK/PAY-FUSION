import React from 'react';
import { getIcon } from '../../utils/icons';

const Icon = ({ name, size = '24px', color = 'currentColor', className = '', ...props }) => {
  const iconData = getIcon(name, size, color);
  
  if (!iconData) {
    return <div className={`icon-placeholder ${className}`} style={{ width: size, height: size }} />;
  }
  
  return (
    <img
      src={iconData.url}
      alt={iconData.alt}
      className={`icon ${className}`}
      style={{
        width: size,
        height: size,
        color: color,
        fill: color
      }}
      {...props}
    />
  );
};

export default Icon;